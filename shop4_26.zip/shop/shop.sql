-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 �?04 �?26 �?09:47
-- 服务器版本: 5.5.53
-- PHP 版本: 5.6.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `shop`
--

-- --------------------------------------------------------

--
-- 表的结构 `kit`
--

CREATE TABLE IF NOT EXISTS `kit` (
  `kit_id` int(22) NOT NULL AUTO_INCREMENT,
  `kit_thum` varchar(255) NOT NULL,
  `kit_type` varchar(255) NOT NULL,
  `kit_pid` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kit_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COMMENT='软件和游戏分类表' AUTO_INCREMENT=32 ;

--
-- 转存表中的数据 `kit`
--

INSERT INTO `kit` (`kit_id`, `kit_thum`, `kit_type`, `kit_pid`) VALUES
(1, '', '社交', 1),
(2, '', '音乐', 1),
(3, '', '效率', 1),
(4, '', '商务', 1),
(5, '', '工具', 1),
(6, '', '软件开发', 1),
(7, '', '教育', 1),
(8, '', '娱乐', 1),
(9, '', '图形和设计', 1),
(10, '', '生活', 1),
(11, '', '视频', 1),
(12, '', '医学', 1),
(13, '', '摄影', 1),
(14, '', '参考', 1),
(15, '', '新闻', 1),
(16, '', '财经', 1),
(17, '', '赛车', 1),
(18, '', '策略', 1),
(20, '', '角色扮演', 1);

-- --------------------------------------------------------

--
-- 表的结构 `nav`
--

CREATE TABLE IF NOT EXISTS `nav` (
  `nav_id` int(22) NOT NULL AUTO_INCREMENT,
  `nav_title` varchar(255) NOT NULL,
  `nav_url` varchar(255) NOT NULL,
  PRIMARY KEY (`nav_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COMMENT='导航表' AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `nav`
--

INSERT INTO `nav` (`nav_id`, `nav_title`, `nav_url`) VALUES
(1, '软件', 'home/software'),
(2, '游戏', 'home/game'),
(3, '排行榜', 'home/rankings'),
(4, '论坛', 'home/comment');

-- --------------------------------------------------------

--
-- 表的结构 `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `news_content` text NOT NULL,
  `news_reply` varchar(255) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`news_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=74 ;

--
-- 转存表中的数据 `news`
--

INSERT INTO `news` (`news_id`, `user_name`, `news_content`, `news_reply`, `date`) VALUES
(1, 'kk', 'ddddddddddd', 'kk', '2018-04-26 03:59:38'),
(2, 'kk', 'ffffffffffffff', 'kk', '2018-04-26 07:27:19'),
(3, 'kk', 'sdssssssssssssssssssssssssssssssssssssss', 'kk', '2018-04-26 03:59:46'),
(4, 'kk', '景福宫的感觉到手机上的疯狂的身份看了就分开的感觉肯定会国防科技的更好地方分开的后果的反馈结果和京东方赶紧的回复给大家发个打开了风华绝代考虑更换发的接口交电话费进度款工会发交电话费见到过。', 'kk', '2018-04-26 03:59:51'),
(5, 'kk', '减肥的减肥是史蒂芬霍金肯定会附近的看法和快速开始发货时间开发快捷地方环境的开发黑客技术山东矿机复活甲的看法还是卡萨丁风华绝代康师傅', 'kk', '2018-04-26 03:59:55'),
(16, 'black', '环境范德萨倒海翻江第三', 'ff', '2018-04-26 07:31:29'),
(14, 'kk', '好什么好', 'kk', '2018-04-26 04:00:08'),
(15, 'black', '被生气', 'ff', '2018-04-26 07:31:26'),
(13, 'black', '好好好', 'ff', '2018-04-26 07:31:19'),
(26, 'ff', 'sdddd', 'ff', '2018-04-26 07:31:15'),
(25, 'ff', 'sdfdgfdg', 'ff', '2018-04-26 07:31:12'),
(23, 'ff', 'sdfdgfdg', 'ff', '2018-04-26 07:32:20'),
(24, 'ff', 'sdfdgfdg', 'ff', '2018-04-20 09:58:12'),
(27, 'ff', 'dfgfds', 'ff', '2018-04-26 09:04:07'),
(28, 'black', 'dfgds', 'ff', '2018-04-26 08:00:54'),
(29, 'black', 'fdgdg ', 'kk', '2018-04-26 08:01:19'),
(30, 'black', 'fdgdfg ', 'kk', '2018-04-26 08:01:23'),
(31, 'black', 'asda ', 'ff', '2018-04-26 08:10:32'),
(32, 'black', 'werfqw ', 'ff', '2018-04-26 08:22:22'),
(33, 'black', '  ssss', 'ff', '2018-04-26 08:22:47'),
(34, 'black', 'dssc', 'ff', '2018-04-26 08:24:48'),
(35, 'black', 'ddd', 'ff', '2018-04-26 08:25:06'),
(36, 'black', 'sdsfs ', 'ff', '2018-04-26 08:51:31'),
(37, 'ff', '行吗', 'ff', '2018-04-26 09:11:55'),
(38, 'ff', '行吗', 'ff', '2018-04-26 09:14:20'),
(39, 'ff', '行吗', 'ff', '2018-04-26 09:15:45'),
(40, 'ff', 'ok?', 'ff', '2018-04-26 09:16:11'),
(41, 'ff', 'ok?', 'ff', '2018-04-26 09:16:26'),
(42, 'ff', 'dfgds', 'ff', '2018-04-26 09:19:04'),
(43, 'ff', 'dfgds', 'ff', '2018-04-26 09:19:21'),
(44, 'ff', 'dfgds', 'ff', '2018-04-26 09:19:37'),
(45, 'ff', 'dfgds', 'ff', '2018-04-26 09:19:45'),
(46, 'ff', 'dfgds', 'ff', '2018-04-26 09:19:54'),
(47, 'ff', 'dfgds', 'ff', '2018-04-26 09:20:11'),
(48, 'ff', 'fffffffffffffffff', 'ff', '2018-04-26 09:23:22'),
(49, 'ff', 'fffffffffffffffff', 'ff', '2018-04-26 09:24:02'),
(50, 'ff', '谁啊', 'ff', '2018-04-26 09:24:26'),
(51, 'ff', 'kaiwmne ', 'ff', '2018-04-26 09:24:57'),
(52, 'ff', '驾驭i不 ', 'ff', '2018-04-26 09:25:49'),
(53, 'ff', '驾驭i不 ', 'ff', '2018-04-26 09:26:17'),
(54, 'ff', '顶顶顶顶顶顶顶顶顶顶顶顶顶顶顶顶 ', 'ff', '2018-04-26 09:26:38'),
(55, 'ff', '鬼地方鬼地方是顶顶顶顶 ', 'ff', '2018-04-26 09:26:52'),
(56, 'ff', '鬼地方鬼地方是顶顶顶顶 ', 'ff', '2018-04-26 09:27:06'),
(57, 'ff', '啊啊啊啊啊啊啊啊啊 ', 'ff', '2018-04-26 09:27:30'),
(58, 'ff', 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 'ff', '2018-04-26 09:29:01'),
(59, 'ff', '水水水水水水水水水水水水水水水水水水水', 'ff', '2018-04-26 09:29:53'),
(60, 'ff', '水水水水水水水水水水水水水水水水水水水', 'ff', '2018-04-26 09:33:53'),
(61, 'ff', '水水水水水水水水水水水水水水水水水水水', 'ff', '2018-04-26 09:36:33'),
(62, 'ff', '水水水水水水水水水水水水水水水水水水水', 'ff', '2018-04-26 09:37:26'),
(63, 'ff', '6788', 'ff', '2018-04-26 09:42:05'),
(64, 'ff', 'tyuyt t ', 'ff', '2018-04-26 09:42:24'),
(65, 'black', 'dsfsf  ', 'ff', '2018-04-26 09:42:32'),
(66, 'ff', '56546', 'ff', '2018-04-26 09:42:37'),
(67, 'black', '你好啊 ff', 'ff', '2018-04-26 09:43:03'),
(68, 'ff', '客服你好', 'ff', '2018-04-26 09:43:14'),
(69, 'ff', '客服你好', 'ff', '2018-04-26 09:43:30'),
(70, 'ff', '多少钱', 'ff', '2018-04-26 09:43:44'),
(71, 'ff', '而微软犬瘟热   ', 'ff', '2018-04-26 09:44:37'),
(72, 'ff', '4545', 'ff', '2018-04-26 09:44:49'),
(73, 'ff', '的发生', 'ff', '2018-04-26 09:45:02');

-- --------------------------------------------------------

--
-- 表的结构 `problem`
--

CREATE TABLE IF NOT EXISTS `problem` (
  `pro_id` int(22) NOT NULL AUTO_INCREMENT,
  `pro_content` text NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `tool_id` int(22) NOT NULL,
  `pro_pid` int(22) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pro_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COMMENT='工具评论' AUTO_INCREMENT=18 ;

--
-- 转存表中的数据 `problem`
--

INSERT INTO `problem` (`pro_id`, `pro_content`, `user_id`, `tool_id`, `pro_pid`, `created_at`) VALUES
(1, '早上还没有 中午出现了 点进来 失效了', '1', 1, 0, '2018-04-17 08:14:04'),
(17, 'dfgdf', '1', 20, 0, '2018-04-24 07:39:56'),
(6, '22', '22', 22, 22, '2018-04-23 07:23:56'),
(7, '33', '33', 33, 33, '2018-04-23 07:24:30'),
(8, '444', '44', 44, 44, '2018-04-23 07:24:30'),
(9, '33', '33', 33, 33, '2018-04-23 07:24:34'),
(10, '444', '44', 44, 44, '2018-04-23 07:24:34'),
(11, '33', '33', 33, 33, '2018-04-23 07:24:41'),
(12, '444', '44', 44, 44, '2018-04-23 07:24:41'),
(13, '33', '33', 33, 33, '2018-04-23 07:24:44'),
(14, '444', '44', 44, 44, '2018-04-23 07:24:44'),
(15, '33', '33', 33, 33, '2018-04-23 07:24:46'),
(16, '444', '44', 44, 44, '2018-04-23 07:24:46');

-- --------------------------------------------------------

--
-- 表的结构 `tool`
--

CREATE TABLE IF NOT EXISTS `tool` (
  `tool_id` int(22) NOT NULL AUTO_INCREMENT,
  `tool_name` varchar(225) NOT NULL,
  `tool_thum` varchar(255) NOT NULL,
  `tool_type` varchar(225) NOT NULL COMMENT '类型',
  `tool_price` int(255) NOT NULL,
  `tool_edition` varchar(255) NOT NULL COMMENT '版本',
  `tool_label` varchar(255) NOT NULL COMMENT '标签',
  `tool_capacity` varchar(225) NOT NULL COMMENT '软件大小',
  `tool_language` varchar(255) NOT NULL COMMENT '语言',
  `tool_compatibility` varchar(255) NOT NULL COMMENT '兼容性',
  `tool_download` int(22) NOT NULL COMMENT '下载量',
  `tool_introduction` text NOT NULL COMMENT '软件介绍',
  `tool_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tool_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COMMENT='工具表' AUTO_INCREMENT=24 ;

--
-- 转存表中的数据 `tool`
--

INSERT INTO `tool` (`tool_id`, `tool_name`, `tool_thum`, `tool_type`, `tool_price`, `tool_edition`, `tool_label`, `tool_capacity`, `tool_language`, `tool_compatibility`, `tool_download`, `tool_introduction`, `tool_time`) VALUES
(1, 'PhpStorm 2017.3.4 for Mac 破解版 Mac系统PHP开发工具', '', '音乐', 10, '2017.3.4', 'PHP', '250 MB', '简体中文', 'OS X 10.11 或更高版本', 2189, 'PhpStorm 2017.3.4 for Mac 破解版 Mac系统PHP开发工具 已通过小编安装运行测试 100%可以使用。\nPhpStorm 2017.3.4 破解版是一个轻量级且便捷的PHP IDE for Mac，由 JetBrains 公司开发的一款商业的 PHP 集成开发工具。其旨在提高用户效率，可深刻理解用户的编码，提供智能代码补全，快速导航以及即时错误检查。', '2018-04-16 20:14:11'),
(2, 'PyCharm 2017.3.4 for Mac 破解版 强大的Mac Python开发工具', '', '音乐', 10, 'PyCharm 2017.3.4', 'Python 开发工具', '276 MB', '英文', 'OS X 10.11 或更高版本', 1373, 'PyCharm 2017.3.4 for Mac 破解版 强大的Mac Python开发工具 已通过小编安装运行测试 100%可以使用。', '2018-04-09 01:19:00'),
(3, 'VMware Fusion Pro 10.1.1破解版 Mac安装Windows必备', '', '商务', 10, '10.1.1', '虚拟机 PD', '491 MB', '简体中文', 'OS X 10.9 或更高版本', 3007, 'VMware Fusion Pro 10.1.1破解版 Mac安装Windows必备 已通过小编安装运行测试 100%可以使用。\nVMware Fusion 10.1.1破解方法：打开终端，将keygen拖入终端窗口然后回车，将得到的序列号输入VMware Fusion 10.1.1激活。\nVMware Fusion 10.1.1破解版是媲美Parallels Desktop一样的Mac虚拟机软件。 \n无论您是希望在 Mac 上运行 Windows XP、Vista、 Win7，还是 Windows 8 或者 Ubuntu、CentOS，VMware Fusion Mac都可让您像启动一个软件一样实现即刻启动和运行而不需重启。 而且，对于 Windows 上运行的程序，VMWare 还能将它们从 Windows 里移出来直接在 Mac 上使用，非常无缝的体验。 \n像运行 Mac 应用程序一样运行 Windows 程序： 使用 VMWare Fusion Mac，你可直接从 Dock、Spotlight 或 Launchpad 中启动 Windows 程序，并可在 Exposé、Spaces 和 Mission Control 中像查看 Mac 应用程序一样查看它们，并可使用 Mac 快捷键和直观的手势与 Windows 程序轻松交互。使得 Windows 应用看起来与用起来就像 Mac 的原生应用一样，非常让人惊叹。你甚至还可以直接从 Mac 系统中直接拖放文件进到 Win 的应用中去…… \n面向 OS X Yosemite 和 Windows 8.1 进行了优化： VMware Fusion Mac 完美支持 Mac OSX Yosemite 与 Windows 8.1，并且充分利用了它们的多项全新技术，进而让用户在 Mac 上获得从未感受过的 Windows 体验。 此外，VMware Fusion Mac 充分利用了 Intel 处理器的多核心处理性能，也更好地利用内存和SSD固态硬盘，使得虚拟的操作系统性能已经能直逼原生安装的了。并且新版本支持 Retina Display 视网膜屏幕，支持USB 3.0，支持雷电接口，大幅改善了电源管理功能。性能更强，但更省电了。 \n在 Mac 下虚拟 Mac OS X Yosemite： VMware Fusion Mac 现在可支持虚拟机中运行 OS X Yosemite 了！ 通过在虚拟机中运行 OS X Mountain Lion、OS X Mountain Lion Server、OS X Lion 和 OS X Lion Server，你可以更充分地利用你的 Mac，也能更方便地在虚拟机里面测试开发中的 Mac 或 iOS 应用程序了！\n高性能的 3D 图形处理能力： VMWare Fusion Mac 支持 3D 图形加速，支持 OpenGL 2.1 及 DirectX 9.0c Shader Model 3 等特性，可以让用户轻松运行诸如 CAD 等性能要求极为严苛的 3D 应用程序，甚至一些热门的3D游戏也不在话下！', '2018-04-09 23:13:10'),
(4, 'Keynote 7.3.1 破解版下载 Apple出品的PowerPoint幻灯片', '', '效率', 10, '7.3.1', 'Mac办公软件 office iWork', '452 MB', '简体中文', 'OS X 10.10 或更高版本', 1334, 'Keynote 7.3.1 破解版下载 Apple出品的PowerPoint幻灯片 已通过小编安装运行测试 100%可以使用。\nKeynote 7.3.1破解版中的新功能\n• 新对象列表便于选择、编辑和整理对象，即使是在复杂的幻灯片上\n• 在黑色背景上显示演讲者注释的新选项使其在弱光环境下演示时更易于阅读\n• 轻松替换整个演示文稿中的字体\n• 新的引线让饼图更易于阅读\n• 使用全新配备 Multi-Touch Bar 的 MacBook Pro 上的 Touch ID 来快速打开受密码保护的演示文稿\n• 新的股票函数和货币函数可在表格中提供最新的证券数据\n• 将交互式演示文稿发布到 Medium、WordPress 以及其他网站\n• 导入 Keynote 1.0 演示文稿\n• 针对您的语言或地区自定日期、时间和货币\n全新 Keynote 7.1 破解版包含强大而易用的工具和出众的的效果，可让你轻松制作出让人望尘莫及的演示文稿。\nKeynote 7.0.5 破解版中的新功能\n• 支持全新 MacBook Pro 上的 Multi-Touch Bar，可让您轻松编辑文本、形状、表格和图表\n• 使用全新 MacBook Pro 上的 Multi-Touch Bar 来控制幻灯片放映的播放\n• 提高了稳定性和性能\n主题选取器让你能预览 30 种 Apple 设计的精美主题，包括全新的和已更新。为演示文稿选定主题之后，用自己的文字和图像替换占位符文本和图形即可。简单易用的工具让你可以很方便地在幻灯片中添加表格、图表、形状、照片和视频，使用影院品质的动画和过渡效果让它栩栩如生，就像是你自己的专属特效团队制作出来的一样。使用全新交互式柱形图、条形图、散点图和气泡图绘制数据。\n使用 iCloud 让你的演示文稿在所有设备间保持更新。只需一个链接便可以与他人即时共享你的演示文稿，让他人获得最新版本，并通过 Mac 或 PC 浏览器在 www.icloud.com 上使用 iCloud 版 Keynote 直接编辑。\n有了 Keynote，你就拥有所需的一切工具，可以无比轻松地制作令人惊叹的演示文稿。\n轻松开始\n• 30 种 Apple 设计的主题让你的演示文稿有个漂亮的开始\n• 使用幻灯片导航器快速预览你的演示文稿，添加新的幻灯片并重新排列\n• 使用全新互动式图表和图表动画让你的观众目不转睛\n• 为幻灯片制作动画效果时实时预览显示效果\n• 使用绚美的预设样式让你的文字、表格、形状和图像漂亮美观\n简单易用的图形处理工具\n• 使用标尺和对齐参考线进行精确编辑\n• 精简的工具栏让你快速访问形状、媒体、表格、图表和共享选项\n• 专业级的图形处理工具\n• 使用即时 Alpha 工具轻松清除图像背景\n• 自由格式的画布、形状和遮罩\n• 连接线\n影院品质的动画效果\n• 更新的影院品质的过渡效果让你轻松制作炫目的演示文稿\n• Magic Move 效果现已扩展到动画以及渐变图形\n• 精美的全新幻灯片过渡效果，包括晾衣绳、对象立体翻转、对象翻转、对象弹出\n• 全新文本和对象动画效果，包括消散、碎屑、渐变和缩放\n• 全新强调构件让你只需轻点一下即可添加效果\n向观众演示\n• 可自定义的演讲者显示支持多达 6 台显示屏\n• 录制的旁白\n• 专为信息站和显示屏创建自动运行的交互式演示文稿\n• 在 iPhone、iPad 或 iPod touch 上使用 iOS 版 Keynote 控制幻灯片放映\niCloud\n• 启用 iCloud，你便可以在 Mac、iPad、iPhone、iPod touch 和 iCloud.com 上访问并编辑演示文稿\n• 通过 Mac 或 PC 浏览器，在 www.icloud.com 上使用 iCloud 版 Keynote 访问并编辑你的演示文稿\n• Keynote 会在你修改后自动保存你的文稿\n共享作品\n• 使用 AirDrop 将你的文稿发送给附近的任何人\n• 通过邮件、信息或新浪微博，以链接方式快速、轻松地共享你的作品\n• 任何有共享文档链接的人都可以随时访问最新版演示文稿，并在 iCloud.com 上和你一同编辑\n• 充分利用图像和影片尺寸优化功能\n• 导入多种媒体格式，包括 JPEG、TIFF、PNG、PSD、EPS、PDF、AIFF、MP3、AAC 和 MOV\n• 作为影片共享到视频网站和社交网站\n• 将你的演示文稿导出为 Microsoft PowerPoint、PDF、QuickTime、HTML 和图像文件\n• 打印演示文稿或针对观众创建讲义时有多种不同布局可以选择   ', '2018-04-09 23:10:09'),
(5, 'Disk Drill 3商业破解版 专业Mac数据恢复软件', '', '工具', 10, '3.5.883', '数据恢复', '32 MB', '简体中文', 'OS X 10.7 或更高版本', 1630, 'Disk Drill 3商业破解版 专业Mac数据恢复软件 已通过小编安装运行测试 100%可以使用。\nDisk Drill  3.5.883 商业版加入了创建可启动恢复驱动器功能、备份功能、清理磁盘、搜索重复文件等实用功能。Disk Drill 3是 Mac 平台上为数不多的数据恢复软件之一，专门补救手贱误删。DiskDrill 功能强大：支持 NTFS, HFS+, FAT32 等多种模式，支持硬盘和 USB 磁盘，提供深度扫描和快速扫描功能，软件首次启动提供简单引导教程。 请注意：数据恢复事关概率，任何软件都不能确保 100% 恢复，管住自己的手，平时养成备份习惯最重要。刚删除文件后立即恢复几率更高，而有写入操作后，原数据可能被彻底覆盖，无法恢复。一项杀手功能是，DiskDrill 提供 Recovery Vault 功能，改善 HFS/HFS+ 和 FAT32 的数据保护特性，提升恢复文件几率。', '2018-04-09 21:11:00'),
(12, 'phplkjakl', 'erwer', 'ds.asd', 11, '1', '111', '1', '11', '1', 111, '111', '2018-04-23 08:46:01'),
(13, '333', '333', '33', 333, '33', '333', '333', '33', '33', 33, '333', '2018-04-23 08:05:54'),
(14, 'ewrw', 'erwer', '111', 11, '1', '111', '1', '11', '1', 111, '111', '2018-04-23 08:05:59'),
(15, '333', '333', '33', 333, '33', '333', '333', '33', '33', 33, '333', '2018-04-23 08:05:59'),
(16, 'ewrw', 'erwer', '111', 11, '1', '111', '1', '11', '1', 111, '111', '2018-04-23 08:06:02'),
(17, '333', '333', '33', 333, '33', '333', '333', '33', '33', 33, '333', '2018-04-23 08:06:02'),
(18, 'ewrw', 'erwer', '111', 11, '1', '111', '1', '11', '1', 111, '111', '2018-04-23 08:06:05'),
(19, '333', '333', '33', 333, '33', '333', '333', '33', '33', 33, '333', '2018-04-23 08:06:05'),
(20, 'ewrw', 'erwer', '111', 11, '1', '111', '1', '11', '1', 111, '111', '2018-04-23 08:06:08'),
(21, '333', '333', '33', 333, '33', '333', '333', '33', '33', 33, '333', '2018-04-23 08:06:08'),
(22, 'f4444', '', '社交', 666, '666', '666', '66', '简体中文', '666', 0, '666', '2018-04-24 03:40:05'),
(23, '11', '', '音乐', 111, '11', '111', '111', '英文', '111', 0, 'ss', '2018-04-25 07:14:06');

-- --------------------------------------------------------

--
-- 表的结构 `topic`
--

CREATE TABLE IF NOT EXISTS `topic` (
  `topic_id` int(22) NOT NULL AUTO_INCREMENT,
  `topic_title` varchar(255) NOT NULL,
  `topic_content` text NOT NULL,
  `user_id` int(22) NOT NULL COMMENT '发帖用户id',
  `topic_number` int(22) NOT NULL COMMENT '回复数',
  `topic_pid` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`topic_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COMMENT='论坛表' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `topic`
--

INSERT INTO `topic` (`topic_id`, `topic_title`, `topic_content`, `user_id`, `topic_number`, `topic_pid`, `created_at`) VALUES
(1, '开通VIP会员服务专享极速下载通道', '百度盘链接总是失效？\r\n速度太慢文件下不下来？\r\n连接断开导致下载不完全？\r\n下载完结果软件损坏不能用？\r\n \r\n为提供全网最佳的Mac App下载体验，我们推出了 VIP会员服务 专享极速下载通道：\r\n1、付费专业云存储 (非百度云) ，链接永不失效，下载速度最高达100M/s且不断线；\r\n2、CDN分布式节点加速下载 (全球500+节点) ；\r\n3、每一个Mac App都经过安装运行测试，100%保证可以使用；\r\n4、客服一对一在线技术支持。\r\n \r\nVIP下载服务器和CDN加速是按流量付费的，VIP用户每下载1M我们都要支付流量费，所以需要捐赠开通，开通后没有其他费用。捐赠用于VIP服务器开支。捐赠本着自愿原则，非常感谢大家的捐赠和支持，我们才能继续为大家提供更多更好的服务。点击开通：macappstore.net/vip', 1, 2, 0, '2018-04-14 02:35:20'),
(2, '精选Mac高清壁纸打包下载', '精选Mac高清壁纸打包下载，目前已收录精选高清壁纸 800 多张，并且不断更新中。\r\nMac高清壁纸打包下载地址：\r\n2016年02月：https://pan.baidu.com/s/1nuFpqmX 密码：nsfr\r\n2016年03月：https://pan.baidu.com/s/1gfJf56b 密码：7yvi\r\n2016年04月：https://pan.baidu.com/s/1hsnpxJ2 密码：jbji\r\n2016年05月：https://pan.baidu.com/s/1c21AFVq 密码：29wd\r\n2016年06月：https://pan.baidu.com/s/1hrSvaWc 密码：uswh\r\n2016年07月：https://pan.baidu.com/s/1jIyfb1s 密码：hw6j\r\n2016年08月：https://pan.baidu.com/s/1jI568a6 密码：5dzt\r\n2016年10月：https://pan.baidu.com/s/1jHZPfCy 密码：cu56\r\n2016年11月：https://pan.baidu.com/s/1c2kkFGs 密码：sx8y\r\n2016年12月：https://pan.baidu.com/s/1o8pqbiU 密码：87s5', 2, 0, 0, '2018-04-12 08:36:41'),
(3, 'VIP点数免费充值和百度云下载失效的说明', '<p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; list-style: none; color: rgb(51, 51, 51); font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 14px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial; outline: none; white-space: normal; line-height: 30px !important;"><span style="color: rgb(255, 0, 0); line-height: 30px !important;">1、百度云下载失效</span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; list-style: none; color: rgb(51, 51, 51); font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 14px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial; outline: none; white-space: normal; line-height: 30px !important;">百度云由于破解被举报等原因会失效，请恕小编精力有限，难以及时更新链接。</p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; list-style: none; color: rgb(51, 51, 51); font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 14px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial; outline: none; white-space: normal; line-height: 30px !important;">急需下载的用户可选择<a href="http://www.macappstore.net/vip/" target="_blank" style="text-decoration-line: none; color: rgb(45, 137, 239); line-height: 30px !important;">捐赠我们</a>开通VIP下载，<a href="http://www.macappstore.net/topic/vip/" target="_blank" style="text-decoration-line: none; color: rgb(45, 137, 239); line-height: 30px !important;">速度非常快</a>，主流宽带都可以满速下载，而且链接不会失效。</p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; list-style: none; color: rgb(51, 51, 51); font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 14px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial; outline: none; white-space: normal; line-height: 30px !important;">VIP下载是使用的付费服务器，按流量付费，所以需要捐赠开通，开通后没有其他费用。</p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; list-style: none; color: rgb(51, 51, 51); font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 14px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial; outline: none; white-space: normal; line-height: 30px !important;">捐赠用于VIP服务器开支，捐赠本着自愿原则。非常感谢大家的捐赠和支持，我们才能继续为大家提供更多更好的服务。</p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; list-style: none; color: rgb(51, 51, 51); font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 14px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial; outline: none; white-space: normal; line-height: 30px !important;">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; list-style: none; color: rgb(51, 51, 51); font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 14px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial; outline: none; white-space: normal; line-height: 30px !important;"><span style="color: rgb(255, 0, 0); line-height: 30px !important;">2、VIP点数免费充值</span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; list-style: none; color: rgb(51, 51, 51); font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 14px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial; outline: none; white-space: normal; line-height: 30px !important;">VIP下载通道是付费服务器，按流量付费，VIP用户每下载1M我们都要支付流量费，为了防止恶意下载，文件较大的软件下载会扣除1-10点数。默认分配100点，如果点数没有了联系客服即可免费充值。</p><p><br/></p>', 3, 1, 0, '2018-04-14 02:58:03');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(22) NOT NULL AUTO_INCREMENT,
  `user_thum` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `is_admin` int(11) NOT NULL DEFAULT '0' COMMENT '0为用户  1为管理员',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COMMENT='用户登录表' AUTO_INCREMENT=10 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`user_id`, `user_thum`, `user_name`, `user_pass`, `is_admin`) VALUES
(1, '', 'ff', 'MTIzNDU2', 0),
(2, '', 'hh', 'MTIzNDU2', 0),
(3, '', 'ss', 'MTIzNDU2', 0),
(5, '20180424\\1e3652c8c964911267150f5a60a05faa.jpg', 'xiao wwwdsdd', '?]u?]u', 1),
(8, '', 'dsfasf', '?m?', 0),
(9, '', 'asdas', '?m?', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
