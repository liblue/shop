<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\phpStudy\WWW\shop\public/../application/index\view\comment\comment.html";i:1522374672;}*/ ?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Mac论坛_苹果软件论坛_Mac破解软件论坛 - MacAppStore.net</title>
<meta name="Keywords" content="Mac论坛,苹果软件论坛,Mac破解软件论坛" />
<meta name="description" content="Mac论坛,苹果软件论坛,Mac破解软件论坛" />
<meta name="viewport" content="width=device-width,user-scalable=no">
<link rel="stylesheet" type="text/css" href="style/style.css" />
<link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon">
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "style/hm.js?82f12669a6dd951e11e0a267709046eb";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
</head>

<body>
	<div class="top cfix">
                <div class="wrap">
                <h1><a href="/">MacAppStore<span>.net</span></a></h1>
		<div class="nav">
                <div class="m" onclick="Show_Hidden(tr1)"><div><span class="icon icon-small"><span class="icon-menu"></span></span></div></div>
		<ul id="tr1"><div>
<li><a href="https://www.macappstore.net/app/" class="s1">软件</a></li><li><a href="https://www.macappstore.net/game/" class="s2">游戏</a></li>			<li><a href="/mac-app-top/">排行榜</a></li>
                        
			<li><a href="/topic">论坛</a></li>
			
			<li class="s"><span class="s1"></span><span class="s2">╲</span><form action="/e/search/index.php" method="post" name="searchform" id="searchform"><input name="keyboard" type="text" id="keyboard" class="key" /><input type="hidden" name="show" value="title" /><input type="hidden" name="tempid" value="1" /><select name="tbname"><option value="download">下载</option></select></form><div class="skey"><a href='https://www.macappstore.net/search/2/' target=_blank>office</a><br><a href='https://www.macappstore.net/search/78/' target=_blank>ntfs</a><br><a href='https://www.macappstore.net/search/403/' target=_blank>xmind</a><br><a href='https://www.macappstore.net/search/53/' target=_blank>迅雷</a><br><a href='https://www.macappstore.net/search/406/' target=_blank>pdf</a><br><a href='https://www.macappstore.net/search/73/' target=_blank>sketch</a><br><a href='https://www.macappstore.net/search/10/' target=_blank>adobe</a><br><a href='https://www.macappstore.net/search/11/' target=_blank>cleanmymac</a><br><a href='https://www.macappstore.net/search/257/' target=_blank>cad</a><br><a href='https://www.macappstore.net/search/33/' target=_blank>clean</a><br></div></li>
		
	        </div></ul>
	        </div>
        </div>
       </div>
<div class="wrap path"><a href="https://www.macappstore.net/">首页</a>&nbsp; 〉&nbsp;<a href="https://www.macappstore.net/topic/">论坛</a></div>
    <div class="wrap app cfix article">
    <div class="topic">
<h2>最新主题</h2>
	<ul>
<li class="icolor"><a href="/u/4"><img src=" /d/file/p/2015/11-17/b09ab14675dbe357093c68bc5dabdfcc.jpg " ></a><span><a href="https://www.macappstore.net/topic/191" title="VIP点数免费充值和百度云下载失效的说明" class="tt">VIP点数免费充值和百度云下载失效的说明<b>置顶</b></a><a href="/u/4">blank</a><b class=g5>admin</b>发表于 1 年前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>106</i></span></li><li class="icolor"><a href="/u/4"><img src=" /d/file/p/2015/11-17/b09ab14675dbe357093c68bc5dabdfcc.jpg " ></a><span><a href="https://www.macappstore.net/topic/vip" title="开通VIP会员服务专享极速下载通道" class="tt">开通VIP会员服务专享极速下载通道<b>置顶</b><b class="rt">推荐</b></a><a href="/u/4">blank</a><b class=g5>admin</b>发表于 1 年前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>34</i></span></li><li class="icolor"><a href="/u/4"><img src=" /d/file/p/2015/11-17/b09ab14675dbe357093c68bc5dabdfcc.jpg " ></a><span><a href="https://www.macappstore.net/topic/51" title="精选Mac高清壁纸打包下载" class="tt">精选Mac高清壁纸打包下载<b>置顶</b></a><a href="/u/4">blank</a><b class=g5>admin</b>发表于 1 年前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>14</i></span></li><li class="icolor"><a href="/u/4"><img src=" /d/file/p/2015/11-17/b09ab14675dbe357093c68bc5dabdfcc.jpg " ></a><span><a href="https://www.macappstore.net/topic/597" title="重要公告：由于VIP下载服务器被恶意攻击，VIP下载通道暂停服务几天" class="tt"><font color='#f00'>重要公告：由于VIP下载服务器被恶意攻击，VIP下载通道暂停服务几天</font><b>置顶</b></a><a href="/u/4">blank</a><b class=g5>admin</b>发表于 1 个月前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>14</i></span></li><li><a href="/u/2327"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/642" title="老板，麻烦加点，谢谢" class="tt">老板，麻烦加点，谢谢</a><a href="/u/2327">此去经年</a><b class=g2>VIP</b>发表于 3 天前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>2</i></span></li><li><a href="/u/4653"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/641" title="站长，Endnote X8求更新！" class="tt">站长，Endnote X8求更新！</a><a href="/u/4653">San123</a><b class=g2>VIP</b>发表于 3 天前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>0</i></span></li><li><a href="/u/8644"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/640" title="请加点。谢谢" class="tt">请加点。谢谢</a><a href="/u/8644">kevinwang</a><b class=g2>VIP</b>发表于 4 天前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li><li><a href="/u/6452"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/639" title="老板，点数不足了，求充值～" class="tt">老板，点数不足了，求充值～</a><a href="/u/6452">yxshw55</a><b class=g2>VIP</b>发表于 4 天前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li><li><a href="/u/8644"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/638" title="请加点谢谢，还有修复链接，好多都无法下载。" class="tt">请加点谢谢，还有修复链接，好多都无法下载。</a><a href="/u/8644">kevinwang</a><b class=g2>VIP</b>发表于 5 天前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>0</i></span></li><li><a href="/u/4511"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/637" title="老大，点数不够了，麻烦充值～～" class="tt">老大，点数不够了，麻烦充值～～</a><a href="/u/4511">syhex</a><b class=g2>VIP</b>发表于 1 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li><li><a href="/u/7813"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/636" title="请老大恢复SketchBook Pro的VIP链接，谢谢" class="tt">请老大恢复SketchBook Pro的VIP链接，谢谢</a><a href="/u/7813">Mingqin.Ji</a><b class=g2>VIP</b>发表于 1 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>0</i></span></li><li><a href="/u/1621"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/635" title="点数没了，站长求充值" class="tt">点数没了，站长求充值</a><a href="/u/1621">cytas</a><b class=g2>VIP</b>发表于 1 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li><li><a href="/u/5585"><img src=" /d/file/p/2017/05-03/253bccfb3c5e06a13671dbcaf63a1578.jpg " ></a><span><a href="https://www.macappstore.net/topic/634" title="不好意思，点数不足了，麻烦加一下点数吧，谢谢" class="tt">不好意思，点数不足了，麻烦加一下点数吧，谢谢</a><a href="/u/5585">yunhe25600</a><b class=g2>VIP</b>发表于 1 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>2</i></span></li><li><a href="/u/7161"><img src=" /d/file/p/2017/09-26/05e2b93b68ca2881a33ac7833e581265.jpg " ></a><span><a href="https://www.macappstore.net/topic/633" title="求加点, 谢谢." class="tt">求加点, 谢谢.</a><a href="/u/7161">casuallife</a><b class=g2>VIP</b>发表于 1 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li><li><a href="/u/5542"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/632" title="用久vip  没有点数了！求加点！&amp;&amp;paste 2.3 为什么还是2.2.5？" class="tt">用久vip  没有点数了！求加点！&amp;&amp;paste 2.3 为什么还是2.2.5？</a><a href="/u/5542">sunnylovecmc</a><b class=g2>VIP</b>发表于 2 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li><li><a href="/u/7507"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/631" title="大佬帮忙加个点。谢谢" class="tt">大佬帮忙加个点。谢谢</a><a href="/u/7507">houchenyu</a><b class=g2>VIP</b>发表于 2 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li><li><a href="/u/5542"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/630" title="paste  2.3   求更新！！！！" class="tt">paste  2.3   求更新！！！！</a><a href="/u/5542">sunnylovecmc</a><b class=g2>VIP</b>发表于 2 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li><li><a href="/u/189"><img src=" /d/file/p/2016/02-02/74423da61e8240fb631a257673baafea.jpg " ></a><span><a href="https://www.macappstore.net/topic/629" title="支持大哥~！大哥没点了~！" class="tt">支持大哥~！大哥没点了~！</a><a href="/u/189">macappstore</a><b class=g2>VIP</b>发表于 2 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li><li><a href="/u/1311"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/628" title="没点了，请加点！谢谢！" class="tt">没点了，请加点！谢谢！</a><a href="/u/1311">cwvonmacapp</a><b class=g2>VIP</b>发表于 2 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li><li><a href="/u/4815"><img src=" /e/data/images/nouserpic.gif " ></a><span><a href="https://www.macappstore.net/topic/627" title="Hype Pro ， VIP 下载 404 Not Found" class="tt">Hype Pro ， VIP 下载 404 Not Found</a><a href="/u/4815">xyang1000</a><b class=g2>VIP</b>发表于 2 周前<a href="https://www.macappstore.net/topic/app/">Mac App</a><i>1</i></span></li>
	</ul>
<div class="page"><a title="Total record">&nbsp;<b>553</b> </a>&nbsp;&nbsp;&nbsp;<b>1</b>&nbsp;<a href="https://www.macappstore.net/topic/index_2.html">2</a>&nbsp;<a href="https://www.macappstore.net/topic/index_3.html">3</a>&nbsp;<a href="https://www.macappstore.net/topic/index_4.html">4</a>&nbsp;<a href="https://www.macappstore.net/topic/index_5.html">5</a>&nbsp;<a href="https://www.macappstore.net/topic/index_6.html">6</a>&nbsp;<a href="https://www.macappstore.net/topic/index_7.html">7</a>&nbsp;<a href="https://www.macappstore.net/topic/index_8.html">8</a>&nbsp;<a href="https://www.macappstore.net/topic/index_9.html">9</a>&nbsp;<a href="https://www.macappstore.net/topic/index_10.html">10</a>&nbsp;<a href="https://www.macappstore.net/topic/index_2.html">下一页</a>&nbsp;<a href="https://www.macappstore.net/topic/index_28.html">尾页</a></div>
    </div>
    <div class="tops">
<h3><a href="/topic/new">新主题</a></h3>
<h2>热门主题</h2>
<ul class="htopic">
<li><a href="/u/5585"><img src=" /d/file/p/2017/05-03/253bccfb3c5e06a13671dbcaf63a1578.jpg " ></a><a href="https://www.macappstore.net/topic/634">不好意思，点数不足了，麻烦加一下点数吧，谢谢</a><i>2</i></li><li><a href="/u/2327"><img src=" /e/data/images/nouserpic.gif " ></a><a href="https://www.macappstore.net/topic/642">老板，麻烦加点，谢谢</a><i>2</i></li><li><a href="/u/3391"><img src=" /e/data/images/nouserpic.gif " ></a><a href="https://www.macappstore.net/topic/621">是的！大量下载404了！！跑路了吗。。。</a><i>1</i></li><li><a href="/u/4815"><img src=" /e/data/images/nouserpic.gif " ></a><a href="https://www.macappstore.net/topic/613">求更新 sketch 49 ，大更新，支持交互原型一站式设计啦！</a><i>1</i></li><li><a href="/u/3430"><img src=" /e/data/images/nouserpic.gif " ></a><a href="https://www.macappstore.net/topic/614">站长你好 可以帮我充下点数吗</a><i>1</i></li><li><a href="/u/6114"><img src=" /e/data/images/nouserpic.gif " ></a><a href="https://www.macappstore.net/topic/615">求修复PDFelement的VIP链接</a><i>1</i></li><li><a href="/u/1545"><img src=" /e/data/images/nouserpic.gif " ></a><a href="https://www.macappstore.net/topic/616">求加点数</a><i>1</i></li><li><a href="/u/8010"><img src=" /d/file/p/2018/01-06/4da78c6844cb07daa9a458e33994ad0a.jpg " ></a><a href="https://www.macappstore.net/topic/617">很多VIP下载都显示404 NOTFOUND 请站长解决</a><i>1</i></li><li><a href="/u/3517"><img src=" /e/data/images/nouserpic.gif " ></a><a href="https://www.macappstore.net/topic/618">spss无法下载</a><i>1</i></li><li><a href="/u/2744"><img src=" /e/data/images/nouserpic.gif " ></a><a href="https://www.macappstore.net/topic/619">求加点</a><i>1</i></li></ul>
    </div>
    </div>
<div class="wrap bottom">
	<h3>©2015 MacAppStore<span>.net</span></h3> Made by <a href="http://blank.yon.com.cn">Blank</a><br>♥ For all mac users. Mac论坛,苹果软件论坛,Mac破解软件论坛<br><a href="/about">关于我们</a> <a href="/legal">版权声明</a> <a href="/links">友情链接</a>
</div>



<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'style/js/push.js';        
    }
    else {
        bp.src = 'style/js/push1.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<script>(function(i,s,o,g,r,a,m){i["DaoVoiceObject"]=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,"script","//widget.daovoice.io/widget/c1bea42b.js","daovoice");</script>
<script>
  daovoice('init', {
    app_id: "c1bea42b",
  });
  daovoice('update');
</script>

<script type="text/javascript">
function Show_Hidden(trid){
    if(trid.style.display=="block"){
        trid.style.display='none';
    }else{
        trid.style.display='block';
    }
}
</script>

</body>
</html>