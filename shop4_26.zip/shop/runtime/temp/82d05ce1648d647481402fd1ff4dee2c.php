<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"D:\0000000\phpStudy\WWW\shop\public/../application/admin\view\news\index.html";i:1524715057;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>layui</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="/shop/public/static/news/layui.css"  media="all">
  <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->
</head>
<body>
            

 
<a class="layui-btn layui-btn-normal" href="http://layim.layui.com/" target="_blank">前去LayIM官网</a>
<br>
<br>
<ul>
   
    <li>
        <blockquote class="layui-elem-quote"  ><a >11111由于LayIM是我们目前唯一的付费组件，所以在你下载的layui包里，并发展下去，那么我我们的促进将会极大！</a></blockquote>
</li>

<?php foreach($data as $k=>$v): ?>


  <li>
  <blockquote class="layui-elem-quote" onclick="add('<?php echo $v['user_name']; ?>')"><button class="layui-btn site-demo-layim" data-type="chat1"><?php echo $v['user_name']; ?></button><?php echo $v['news_content']; ?></blockquote>
</li>
<?php endforeach; ?>

</ul>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 50px;">
  <legend>面板外的操作示例</legend>
</fieldset>
 

              
          

<!-- 注意：如果你直接复制所有代码到本地，上述js路径需要改成你本地的 -->
<script>
    
    function add(user_name){
 
      window.open("<?php echo url('admin/news/content'); ?>?user_name="+user_name,'baidu','height=600, width=500, top=200, left=800, toolbar=no, menubar=no, scrollbars=no, resizable=false, location=no, status=no');
    }
    </script>

</body>
</html>