<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:71:"D:\phpStudy\WWW\shop\public/../application/home\view\comment\reply.html";i:1523859553;s:60:"D:\phpStudy\WWW\shop\application\home\view\commont\head.html";i:1524038911;s:60:"D:\phpStudy\WWW\shop\application\home\view\commont\tail.html";i:1524043945;}*/ ?>
<!doctype html>
<html>
<head>
    <!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <meta name="referrer" content="always">
    <title>PhpStorm 2017.3.4 for Mac &#8211; Mac软件</title>
    <script type="text/javascript">
        window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/macapp.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.3"}};
        !function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56692,8205,9792,65039],[55357,56692,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
    </script>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <script type='text/javascript' src='/shop/public/style/js/jquery.js'></script>
    <script type='text/javascript' src='/shop/public/style/js/jquery-migrate.min.js'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var IwNRCargs = {"rightclick":"Y","draganddrop":"Y"};
        /* ]]> */
    </script>
    <script type='text/javascript' src='/shop/public/style/js/no-right-click.js'></script>
    <script type='text/javascript' src='/shop/public/style/js/nanobar.js'></script>
    <style id="themedd-custom-css" type="text/css">
        .site-description { color:#a2a2a2;}a { color:#448fd5;}a:hover { color:#215b92;}#masthead { background-color:#ffffff;}.main-navigation a { color:#696969;}.main-navigation li:hover > a, .main-navigation li.focus > a { color:#222222;}.main-navigation .current-menu-item > a, .main-navigation .current_page_ancestor > a, .main-navigation .current_page_ancestor > a:hover, .main-navigation li.current_page_ancestor:hover > a { color:#222222;}.main-navigation ul ul li, .main-navigation ul ul { background:#222222;}.main-navigation .sub-menu a { color:#a2a2a2;}.main-navigation .sub-menu li:hover > a, .main-navigation .sub-menu li.focus > a { color:#ffffff;}.main-navigation .sub-menu .current-menu-item a { color:#ffffff;}.main-navigation .sub-menu .current-menu-item a:hover { color:#ffffff;}#site-header-secondary-menu a { color:#696969;}#site-header-secondary-menu a:hover { color:#222222;}.navCart-mobile .navCart-icon { fill:#222222;}.navCart-icon { fill:#222222;}.button, button, input[type="submit"], #submit { background:#448fd5; border-color: #448fd5; }.button:hover, .button:focus, button:hover, input[type="submit"]:hover, #submit:hover { background:#2f83d0; border-color: #2f83d0; }.button, button, input[type="submit"], #submit { color:#ffffff; }.button:hover, button:hover, input[type="submit"]:hover, #submit:hover { color:#ffffff; }#menu-toggle { background:#222222; border-color: #222222; }#menu-toggle { color:#ffffff; }#mobile-menu a, #mobile-menu .current-menu-item > a, .dropdown-toggle, .dropdown-toggle:hover  { color:#222222; }.site-footer { background-color:#ffffff; }.site-footer { color:#a2a2a2; }.site-footer a { color:#a2a2a2; }.site-footer a:hover { color:#222222; }.site-footer h1, .site-footer h2, .site-footer h3, .site-footer h4, .site-footer h5, .site-footer h6 { color:#222222; }.site-info { color:#a2a2a2; }		</style>

    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "/shop/public/style/js/hm.js";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>

    <link rel="stylesheet" type="text/css" href="/shop/public/style/style.css" />
    <link rel="stylesheet" type="text/css" href="/shop/public/style/lightbox.css" />
    <script src="/shop/public/style/js/jquery-1.8.2.min.js" type="text/javascript"></script>
    <script src="/shop/public/style/js/delayLoading.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(function () {
            $("img").delayLoading({
                errorImg: "",                        // 读取图片错误时替换图片(默认：与defaultImg一样)
                imgSrcAttr: "originalsrc",           // 记录图片路径的属性(默认：originalSrc，页面img的src属性也要替换为originalSrc)
                beforehand: 0,                       // 预先提前多少像素加载图片(默认：0)
                event: "scroll",                     // 触发加载图片事件(默认：scroll)
                duration: "normal",                  // 三种预定淡出(入)速度之一的字符串("slow", "normal", or "fast")或表示动画时长的毫秒数值(如：1000),默认:"normal"
                container: window,                   // 对象加载的位置容器(默认：window)
                success: function (imgObj) { },      // 加载图片成功后的回调函数(默认：不执行任何操作)
                error: function (imgObj) { }         // 加载图片失败后的回调函数(默认：不执行任何操作)
            });
        });
    </script>
</head>

<body>
<div class="top cfix">
    <div class="wrap">
        <h1><a href="<?php echo url('./'.'home/index'); ?>">MacAppStore<span>.net</span></a></h1>
        <div class="nav">
            <div class="m" onclick="Show_Hidden(tr1)"><div><span class="icon icon-small"><span class="icon-menu"></span></span></div></div>

            <ul id="tr1">
                <div>
                    <?php foreach($nav as $vo): ?>
                        <li><a href="<?php echo url('./'.$vo['nav_url']); ?>" class="s1"><?php echo $vo['nav_title']; ?></a></li>
                    <?php endforeach; if(\think\Session::get('user_name')): ?>
                        <li style="margin-right:50px;float:right"><a href="<?php echo url('./'.'home/logout'); ?>">退出</a></li>
                        <li style="margin-right:50px;float:right"><a href=""><?php echo \think\Session::get('user_name'); ?></a></li>
                    <?php else: ?>
                        <li style="margin-right:50px;float:right"><a href="<?php echo url('./'.'home/register'); ?>">注册</a></li>
                        <li style="margin-right:20px;float:right;"><a href="<?php echo url('./'.'home/login'); ?>">登录</a></li>
                    <?php endif; ?>
               </div>
            </ul>
        </div>
    </div>
</div>

</body>
</html>

</head>

<body>

<div class="wrap path"><a href="https://www.macappstore.net/">首页</a>&nbsp; 〉&nbsp;<a
        href="https://www.macappstore.net/topic/">论坛</a>&nbsp; 〉&nbsp;<a href="https://www.macappstore.net/topic/app/">Mac
    App</a></div>

<div class="wrap app cfix article">

    <div class="topics">
        <h1><?php echo $topic['topic_title']; ?></h1>
        <div class="topicinfo"><span class="g5"><?php echo $userd['user_name']; ?></span>发表于 <?php echo $topic['created_at']; ?>
            <img src="<?php echo $userd['user_thum']; ?>">
        </div>
        <div id="txt">
            <div><?php echo $topic['topic_content']; ?></div>
        </div>

            <?php foreach($newreply as $vo): ?>
            <li>
                <a href=""><img src="<?php echo $vo['user']['user_thum']; ?>"></a>
                <span style="margin-left:64px"><i><a href='' target='_blank'><?php echo $vo['user']['user_name']; ?></a>
                    <?php echo $vo['created_at']; ?><b>1</b></i><?php echo $vo['reply_content']; ?></span>
            </li>
            <?php endforeach; ?>

        <script>
            function CheckPl(obj) {
                if (obj.saytext.value == "") {
                    alert("您没什么话要说吗？");
                    obj.saytext.focus();
                    return false;
                }
                return true;
            }
        </script>

        <form action="<?php echo url('./'.'home/answer'); ?>" method="post" name="saypl" id="saypl"
              onsubmit="return CheckPl(document.saypl)">
            <?php if(\think\Session::get('user_name')): ?>
                <div id="plpost">
                    <textarea name="reply_content" rows="6" id="saytext" placeholder="请输入你的回复"></textarea>
                    <input type="submit" value="提交" class="btn" style="float:right">
                    <input name="topic_id" type="hidden" id="id" value="<?php echo $topic['topic_id']; ?>"/>
                </div>
            <?php else: ?>
            <div id="plpost">
                <textarea name="saytext" rows="6" id="saytext" placeholder="回复请先登陆"></textarea>
                <input type="submit" value="提交" class="btn" disabled="disabled" style="float:right">
            </div>
            <?php endif; ?>
        </form>
        <script>
            function refreshVerify() {
                var ts = Date.parse(new Date())/1000;
                var img = document.getElementById('verify_img');
                img.src = "/shop/public/captcha?id="+ts;
            }
        </script>

    </div>
    <div class="tops">
        <?php if(\think\Session::get('user_name')): ?>
            <h3><a href="<?php echo url('./'.'home/release'); ?>">新主题</a></h3>
        <?php else: ?>
            <h3><a href="">新主题</a></h3>
        <?php endif; ?>
        <h2>热门主题</h2>
        <ul class="htopic">
            <?php foreach($newhot as $v): ?>
            <li>
                <a href="<?php echo url('./'.'home/reply'); ?>?topic_id=<?php echo $v['topic_id']; ?>"><img src="<?php echo $v['user']['user_thum']; ?>"></a>
                <a href="<?php echo url('./'.'home/reply'); ?>?topic_id=<?php echo $v['topic_id']; ?>"><?php echo $v['topic_title']; ?></a><i><?php echo $v['topic_number']; ?></i>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>
<!doctype html>
<html>
<head></head>
<body>

<div class="wrap bottom">
    <h3>©2015 MacAppStore<span>.net</span></h3> Made by <a href="">Blank</a><br>♥ For all mac users. Mac软件<br><a href="">关于我们</a> <a href="">版权声明</a> <a href="">友情链接</a>
</div>

<script type="text/javascript">
    var options = { bg:'#2d89ef', id:'alobaidi-loading-bar' };
    var nanobar = new Nanobar( options );
    nanobar.go(100);
</script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var edd_scripts = {"ajaxurl":"https:\/\/macapp.org\/wp-admin\/admin-ajax.php","position_in_cart":"","has_purchase_links":"","already_in_cart_message":"You have already added this item to your cart","empty_cart_message":"Your cart is empty","loading":"Loading","select_option":"Please select an option","is_checkout":"0","default_gateway":"xh_wechat_payment_edd","redirect_to_checkout":"1","checkout_page":"https:\/\/macapp.org\/checkout\/","permalinks":"1","quantities_enabled":"","taxes_enabled":"0"};
    /* ]]> */
</script>
<script type='text/javascript' src='/shop/public/style/js/edd-ajax.min.js'></script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var screenReaderText = {"expand":"<span class=\"screen-reader-text\">expand child menu<\/span>","collapse":"<span class=\"screen-reader-text\">collapse child menu<\/span>"};
    var cartQuantityText = {"singular":"item","plural":"items"};
    /* ]]> */
</script>
<script type='text/javascript' src='/shop/public/style/js/themedd.min.js'></script>
<script type='text/javascript' src='/shop/public/style/js/comment-reply.min.js'></script>
<script type='text/javascript' src='/shop/public/style/js/wp-embed.min.js'></script>
<script async="async" type='text/javascript' src='/shop/public/style/js/form.js'></script>
<script>
    (function(){
        var bp = document.createElement('script');
        var curProtocol = window.location.protocol.split(':')[0];
        if (curProtocol === 'https') {
            bp.src = '/shop/public/style/js/push.js';
        }
        else {
            bp.src = '/shop/public/style/js/push1.js';
        }
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(bp, s);
    })();
</script>

<script type="text/javascript">
    function Show_Hidden(trid){
        if(trid.style.display=="block"){
            trid.style.display='none';
        }else{
            trid.style.display='block';
        }
    }
</script>

<script charset="utf-8" type="text/javascript" src="/shop/public/style/js/changyan.js" ></script>
<script type="text/javascript">
    window.changyan.api.config({
        appid: 'cysUr6m2h',
        conf: 'prod_67283d4ee701130f42ec637248de59e2'
    });
</script>

<script>
    daovoice('init', {
        app_id: "c1bea42b",
    });
    daovoice('update');
</script>

<script type="text/javascript" src="/shop/public/style/js/ajax.js"></script>
<script src="/shop/public/style/js/lightbox-2.6.min.js"></script>
<script>
    var h = document.getElementById("txt").clientHeight;
    if ( h > 245 ) {
        document.getElementById("txt").style.height = "245px";
        document.getElementById("txt").style.overflow = "hidden";
        document.getElementById("moretxt").style.display = "block";
        document.getElementById("more").onclick = function() {
            document.getElementById("txt").style.height = "auto";document.getElementById("moretxt").style.display = "none";
        }
    }
    function getcookie(objname)
    }
    var uname = getcookie("umulsmlusername");
    var url = document.getElementById("download_link").href;
    if (uname!="" || uname) {
        document.getElementById("download_link").href = url+"?u="+uname+"&app=Amadeus Pro";
    }
</script>



</body>
</html>



</body>
</html>