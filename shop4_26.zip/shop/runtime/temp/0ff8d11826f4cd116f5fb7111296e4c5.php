<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:75:"D:\0000000\phpStudy\WWW\shop\public/../application/admin\view\tool\add.html";i:1524539844;s:70:"D:\0000000\phpStudy\WWW\shop\application\admin\view\public\header.html";i:1523261997;}*/ ?>
<!DOCTYPE html>
<html>
  
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.0</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/shop/public/static/admin/css/font.css">
    <link rel="stylesheet" href="/shop/public/static/admin/css/xadmin.css">
    <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="/shop/public/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/shop/public/static/admin/js/xadmin.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
      <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
      <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  
  <body> 
    <div class="x-body">
       <form class="layui-form" action="<?php echo url('admin/tool/save'); ?>">
  <div class="layui-form-item">
    <label class="layui-form-label">产品名称</label>
    <div class="layui-input-block">
      <input type="text" name="tool_name" lay-verify="title" autocomplete="off" placeholder="请输入内容" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">标签</label>
    <div class="layui-input-block">
      <input type="text" name="tool_label"  lay-verify="biaoqian"   placeholder="请输入内容" autocomplete="off" class="layui-input">
    </div>
  </div>
  
  <div class="layui-form-item">
    <div class="layui-inline">
      <label class="layui-form-label">价格</label>
      <div class="layui-input-inline">
        <input type="tel" name="tool_price" lay-verify="price"  placeholder="单位（元）" autocomplete="off" class="layui-input">
      </div>
    </div>
    <div class="layui-inline">
      <label class="layui-form-label">大小</label>
      <div class="layui-input-inline">
        <input type="text" name="tool_capacity"  lay-verify="store"   placeholder="单位（M）" autocomplete="off" class="layui-input">
      </div>
    </div>
        <div class="layui-inline">
      <label class="layui-form-label">版本号</label>
      <div class="layui-input-inline">
        <input type="text" name="tool_edition"  lay-verify="version" autocomplete="off" class="layui-input">
      </div>
    </div>
       <div class="layui-inline">
      <label class="layui-form-label">兼容性</label>
      <div class="layui-input-inline">
        <input type="text" name="tool_compatibility"  lay-verify="jianrong" autocomplete="off" class="layui-input">
      </div>
    </div>
 
  </div>
  
 
  <div class="layui-form-item">
    <label class="layui-form-label">语言</label>
    <div class="layui-input-block">
      <select name="tool_language"   lay-verify="language">
        <option value=""></option>
        
       
        <option value="简体中文">简体中文</option>
        <option value="英文">英文</option>
      
      </select>
    </div>
  </div>
  

  

  <div class="layui-form-item">
    <label class="layui-form-label">类别</label>
    <div class="layui-input-block">
      <select name="tool_type"   lay-verify="kit">
        <option value=""></option>
        
        <?php foreach($kit as $v): ?>
        <option value="<?php echo $v['kit_type']; ?>"><?php echo $v['kit_type']; ?></option>
        <?php endforeach; ?>
      
      </select>
    </div>
  </div>
         <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">软件介绍</label>
    <div class="layui-input-block">
      <textarea placeholder="请输入内容" class="layui-textarea"   lay-verify="intro"   name="tool_introduction"></textarea>
    </div>
  </div>  
             <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">特点</label>
    <div class="layui-input-block">
      <textarea placeholder="请输入内容" class="layui-textarea"  name="point"></textarea>
    </div>
  </div> 
            <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">破解方法</label>
    <div class="layui-input-block">
      <textarea placeholder="请输入内容" class="layui-textarea"  name="method"></textarea>
    </div>
  </div> 
           
           
                 <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">屏幕截图</label>
    <div class="layui-input-block">
      <textarea placeholder="请输入内容" class="layui-textarea"  name="imgs"></textarea>
    </div>
  </div>
           
             <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit="" lay-filter="demo1">立即提交</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
       </form>
    </div>
    <script>
        layui.use(['form','layer'], function(){
            $ = layui.jquery;
          var form = layui.form
          ,layer = layui.layer;
        
          //自定义验证规则
          form.verify({
            price: function(value){
              if(value.length < 1 ){
                return '价格不得为空';
              }
              if(isNaN(value)){
                  return '价格必须为数字';
              }
               if(value.length>7){
                  return '价格不合理,应低于1000000';
              }
            },
           biaoqian: function(value){
              if(value.length < 1){
                return '标签不得为空';
              }
            },
             store: function(value){
              if(value.length < 1){
                return '大小不得为空';
              }
               if(isNaN(value)){
                  return '大小必须为数字，单位不填';
              }
               if(value.length>7){
                  return '大小不合理,应低于2048M';
              }
            },
            version: function(value){
              if(value.length < 1){
                return '版本号不得为空';
              }
            },
             jianrong: function(value){
              if(value.length < 1){
                return '兼容性不得为空';
              }
            },
             language: function(value){
              if(value.length < 1){
                return '语言不得为空';
              }
            },
             kit: function(value){
              if(value.length < 1){
                return '未选择类别';
              }
            },
            intro: function(value){
              if(value.length < 1){
                return '介绍不得为空';
              }
            },
            
             title: function(value){
              if(value.length < 1){
                return '名称不得为空';
              }
            }
            
            ,pass: [/(.+){6,12}$/, '密码必须6到12位']
            ,repass: function(value){
                if($('#L_pass').val()!=$('#L_repass').val()){
                    return '两次密码不一致';
                }
            }
          });

          //监听提交
          form.on('submit(add)', function(data){
            console.log(data);
            //发异步，把数据提交给php
            layer.alert("增加成功", {icon: 6},function () {
                // 获得frame索引
                var index = parent.layer.getFrameIndex(window.name);
                //关闭当前frame
                parent.layer.close(index);
            });
            return false;
          });
          
          
        });
    </script>
    <script>var _hmt = _hmt || []; (function() {
        var hm = document.createElement("script");
        hm.src = "https://hm.baidu.com/hm.js?b393d153aeb26b46e9431fabaf0f6190";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
      })();</script>
  </body>

</html>