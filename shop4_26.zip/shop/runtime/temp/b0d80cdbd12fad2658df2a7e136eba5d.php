<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"D:\phpStudy\WWW\shop\public/../application/home\view\buy\index.html";i:1522381558;}*/ ?>
55555