<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\phpStudy\WWW\shop\public/../application/index\view\content\content.html";i:1522373687;}*/ ?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Amadeus Pro 破解版_Amadeus Pro for Mac_Amadeus Pro - Mac破解软件下载 MacAppStore.net</title>
<meta name="Keywords" content="Amadeus Pro Mac版,Amadeus Pro 破解版" />
<meta name="description" content="Amadeus Pro 破解版 强大的多轨音频编辑器 Mac版下载，Amadeus Pro 破解版 强大的多轨音频编辑器 经过小编亲测可用，请放心下载。" />
<meta name="viewport" content="width=device-width,user-scalable=no">
<link rel="stylesheet" type="text/css" href="style/style.css" />
<link rel="stylesheet" type="text/css" href="style/lightbox.css" />

<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "style/js/hm.js";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
<script src="style/js/jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="style/js/delayLoading.min.js" type="text/javascript"></script>
<script type="text/javascript">
$(function () {
	$("img").delayLoading({
		errorImg: "",                        // 读取图片错误时替换图片(默认：与defaultImg一样)
		imgSrcAttr: "originalsrc",           // 记录图片路径的属性(默认：originalSrc，页面img的src属性也要替换为originalSrc)
		beforehand: 0,                       // 预先提前多少像素加载图片(默认：0)
		event: "scroll",                     // 触发加载图片事件(默认：scroll)
		duration: "normal",                  // 三种预定淡出(入)速度之一的字符串("slow", "normal", or "fast")或表示动画时长的毫秒数值(如：1000),默认:"normal"
		container: window,                   // 对象加载的位置容器(默认：window)
		success: function (imgObj) { },      // 加载图片成功后的回调函数(默认：不执行任何操作)
		error: function (imgObj) { }         // 加载图片失败后的回调函数(默认：不执行任何操作)
	});
});
</script>
</head>

<body>
	<div class="top cfix">
                <div class="wrap">
                <h1><a href="/">MacAppStore<span>.net</span></a></h1>
		<div class="nav">
                <div class="m" onclick="Show_Hidden(tr1)"><div><span class="icon icon-small"><span class="icon-menu"></span></span></div></div>
		<ul id="tr1"><div>
<li><a href="https://www.macappstore.net/app/" class="s1">软件</a></li><li><a href="https://www.macappstore.net/game/" class="s2">游戏</a></li>			<li><a href="/mac-app-top/">排行榜</a></li>
                     
	
			<li><a href="/topic">论坛</a></li>
			
			<li class="s"><span class="s1"></span><span class="s2">╲</span><form action="/e/search/index.php" method="post" name="searchform" id="searchform"><input name="keyboard" type="text" id="keyboard" class="key" /><input type="hidden" name="show" value="title" /><input type="hidden" name="tempid" value="1" /><select name="tbname"><option value="download">下载</option></select></form><div class="skey"><a href='https://www.macappstore.net/search/78/' target=_blank>ntfs</a><br><a href='https://www.macappstore.net/search/2/' target=_blank>office</a><br><a href='https://www.macappstore.net/search/403/' target=_blank>xmind</a><br><a href='https://www.macappstore.net/search/53/' target=_blank>迅雷</a><br><a href='https://www.macappstore.net/search/73/' target=_blank>sketch</a><br><a href='https://www.macappstore.net/search/406/' target=_blank>pdf</a><br><a href='https://www.macappstore.net/search/10/' target=_blank>adobe</a><br><a href='https://www.macappstore.net/search/11/' target=_blank>cleanmymac</a><br><a href='https://www.macappstore.net/search/33/' target=_blank>clean</a><br><a href='https://www.macappstore.net/search/257/' target=_blank>cad</a><br></div></li>
			
	        </div></ul>
	        </div>
        </div>
       </div>
<div class="wrap path"><a href="https://www.macappstore.net/">首页</a>&nbsp; 〉&nbsp;<a href="https://www.macappstore.net/app/">软件</a>&nbsp; 〉&nbsp;<a href="https://www.macappstore.net/music/">音乐</a></div>
    <div class="wrap app cfix">
    <div class="left">
    <span class="nub"><a href="JavaScript:makeRequest('/e/public/digg?classid=4&id=321&dotop=1&doajax=1&ajaxarea=diggnum','EchoReturnedText','GET','');" title="点赞+1">♥ <label id="diggnum">12</label></a></span>
    <span class="ico"><img src="/d/file/music/2016/07-14/5559c91b2a1a146e0530468dbdb86c12.png" alt="Amadeus Pro"></span>

<span class="down d0&nbsp;&nbsp;1">
    <a href="/get-4-321-0.html?app=Amadeus Pro" target="_blank" class="durl">
    <div class="dbtn">下载</div>
    <div class="qcode">关注微信公众号发送<br><b>Amadeus</b> 获取提取码<br><br><img src="/img/qrcode.jpg" alt="关注微信公众号，发送信息“Amadeus”获取 Amadeus Pro 提取码。"></div>
    </a>
    <a href="/vip/" target="_blank">网盘链接失效，速度慢?<br>49元VIP享全站极速下载</a>
    <a id="download_link" href="/get-4-321-1.html" title="Amadeus Pro 破解版 强大的多轨音频编辑器下载" target="_blank">VIP极速下载</a>
    <a href="/tips/mac-setup-app/" target="_blank">提示文件损坏解决方法</a>
</span>

    <span class="cert"><img src="/img/cert.png"></span>
    <div class="testmac"><span class="test" ontouchstart=""><h4><i>✔</i>小编亲测可用</h4><p>关于测试 Mac</p>型号：Mac mini (2011 年中)<br>处理器：2.3 GHz Intel Core i5<br>内存：8 GB 1333 MHz DDR3<br>硬盘：Samsung SSD 840 Series 120GB + APPLE HDD 500GB<br>显卡：Intel HD Graphics 3000 512MB<br>显示器：DELL U2412M 24-inch (1920 x 1200)<br>系统版本：macOS Sierra 10.12 (16A323)</span></div>
    <div class="macs"><a href="http://buymac.com.cn/">buymac<span>.com.cn</span></a><li><a href="http://buymac.com.cn/imac-21" title="iMac ME086CH/A 报价"><img src="/d/file/buymac/imac-21/2015/06-28/65-65-86e2020b6ce1571a8a12d5ab289372b3.jpg" alt="iMac ME086CH/A 报价">iMac ME086CH/A</a></li><li><a href="http://buyiphone.cn/175" title="星空数码8月12日iPhone 7 / iPhone 7 Plus报价"><img src="https://www.macappstore.net/img/iphone6.png" alt="星空数码8月12日iPhone 7 / iPhone 7 Plus报价">iPhone 6s 16GB</a>RMB -</li>
<li><a href="http://buyiphone.cn/175" title="星空数码8月12日iPhone 7 / iPhone 7 Plus报价"><img src="https://www.macappstore.net/img/iphone6p.png" alt="星空数码8月12日iPhone 7 / iPhone 7 Plus报价">iPhone 6s Plus 16GB</a>RMB -</li><li><a href="http://buyiphone.cn/ipad/146" title="星空数码9月10日 iPad Pro / Air 2 / mini 4报价"><img src="https://www.macappstore.net/img/ipadmini.png" alt="星空数码9月10日 iPad Pro / Air 2 / mini 4报价">iPad mini 2 16GB</a>RMB 1800</li>
<li><a href="http://buyiphone.cn/ipad/146" title="星空数码9月10日 iPad Pro / Air 2 / mini 4报价"><img src="https://www.macappstore.net/img/ipadmini.png" alt="星空数码9月10日 iPad Pro / Air 2 / mini 4报价">iPad mini 4 16GB</a>RMB -</li></div>
    </div>
    <div class="intro">
    <h1>Amadeus Pro 破解版 强大的多轨音频编辑器</h1>
    <h2><a href="/developer/HairerSoft/">HairerSoft</a> 〉</h2>
    <div class="spec">
    <ul>
        <li>类别：<a href="https://www.macappstore.net/music/">音乐</a></li>
        <li>版本：2.4</li>
        <li>大小：19.2 MB</li>
        <li>语言：简体中文</li>
        <li>标签：<a href="https://www.macappstore.net/tag/%E9%9F%B3%E9%A2%91%E7%BC%96%E8%BE%91/" target="_blank">音频编辑</a></li>
        <li>兼容性：OS X 10.6.6 或更高版本</li>
        <li>更新：2017年07月28日</li>
        <li>下载：269 次</li>
    </ul>
    </div>
    <h3>软件介绍</h3>
    <div id="more">
    <div id="txt">
<div>Amadeus Pro 破解版 强大的多轨音频编辑器 已通过小编安装运行测试 100%可以使用。</div><div>Amadeus Pro 是一款Mac上专业的多轨音频编辑器，支持现场录音,数字录音和记录软件,支持各种声音之间的转换.支持多种格式,如 Mp3, MPEG-4 AAC, AIFF, WAVE, WMA, CAF等，功能非常强大。</div>
<div>Amadeus Pro 破解方法：</div>
<div>1、拖动 Amadeus Pro.app 到 Applications 目录完成安装；</div>
<p>2、打开 Amadeus Pro 2.x [SP].app，将应用程序目录内的 Amadeus Pro.app 拖到 Amadeus Pro 2.x [SP].app 窗口上即可破解成功。&nbsp;</p>    </div>
    <div id="moretxt">更多...</div>
    </div>
    <h3>屏幕截图</h3>
    <div class="screenshots">
    <table cellspacing="0">
    <tr>
<td><a href="http://a4.mzstatic.com/us/r30/Purple/v4/23/8d/d7/238dd7ea-919a-5eb4-5bc9-78c833ec45be/screen800x500.jpeg" data-lightbox="roadtrip"><img src="/img/blank.gif" originalsrc="http://a4.mzstatic.com/us/r30/Purple/v4/23/8d/d7/238dd7ea-919a-5eb4-5bc9-78c833ec45be/screen800x500.jpeg" alt=""></a></td><td><a href="http://a2.mzstatic.com/us/r30/Purple/v4/60/39/11/603911a7-03f6-a3c6-caa9-878d2f985c63/screen800x500.jpeg" data-lightbox="roadtrip"><img src="/img/blank.gif" originalsrc="http://a2.mzstatic.com/us/r30/Purple/v4/60/39/11/603911a7-03f6-a3c6-caa9-878d2f985c63/screen800x500.jpeg" alt=""></a></td><td><a href="http://a5.mzstatic.com/us/r30/Purple/v4/2f/27/7c/2f277c3e-c814-7672-f00c-6a3e5106528f/screen800x500.jpeg" data-lightbox="roadtrip"><img src="/img/blank.gif" originalsrc="http://a5.mzstatic.com/us/r30/Purple/v4/2f/27/7c/2f277c3e-c814-7672-f00c-6a3e5106528f/screen800x500.jpeg" alt=""></a></td>    </tr>
    </table>
    </div>
    <h3>热门音乐App</h3>
    <div class="mapps">
    <table cellspacing="0">
    <tr>
<td><a href="http://www.macappstore.net/boom2" title="Boom 2 1.6破解版 最强Mac系统级音频增强和均衡器" class="title"><img src="/img/blank.gif" originalsrc="/d/file/music/2016/03-08/fcc293e8327f1d1941ede69439d681ed.png" alt="Boom 2">Boom 2</a>3254 次下载</td><td><a href="https://www.macappstore.net/qq-music-for-mac" title="QQ音乐 for Mac" class="title"><img src="/img/blank.gif" originalsrc="/d/file/music/2015/06/14/da79b9e8ab46653b30803a154e330b52.png" alt="QQ音乐">QQ音乐</a>2254 次下载</td><td><a href="http://www.macappstore.net/adobe-audition-cc-2015-for-mac" title="Adobe Audition CC 2017 10.0 for Mac 简体中文破解版 专业Mac音频处理软件" class="title"><img src="/img/blank.gif" originalsrc="/d/file/music/2016/01-23/757608e0bc2f8a79746d4ad9691da2c0.png" alt="Adobe Audition CC 2017">Adobe Audition CC 2017</a>2233 次下载</td><td><a href="https://www.macappstore.net/logic-pro-x" title="Logic Pro X 10.3.3 破解版 Apple出品的音乐制作软件" class="title"><img src="/img/blank.gif" originalsrc="/d/file/music/2016/01-04/74624bf7a178b0b727dd834f64e48a89.png" alt="Logic Pro X">Logic Pro X</a>2217 次下载</td><td><a href="http://www.macappstore.net/spotify" title="Spotify 在线流媒体音乐播放平台" class="title"><img src="/img/blank.gif" originalsrc="/d/file/entertainment/2015/10-18/0108eac85b71daa49044c7e9acd439b8.png" alt="Spotify">Spotify</a>914 次下载</td><td><a href="http://www.macappstore.net/noizio" title="Noizio for Mac 破解版 非常棒的环境音效模拟软件" class="title"><img src="/img/blank.gif" originalsrc="/d/file/music/2016/06-07/edb1c71d01eb5d7a7bb004b1522fa0e2.png" alt="Noizio">Noizio</a>850 次下载</td><td><a href="http://www.macappstore.net/163music" title="网易云音乐 for Mac" class="title"><img src="/img/blank.gif" originalsrc="/d/file/music/2016/02-17/16f113c819e55bbab2101fbfc0ff0b6c.png" alt="网易云音乐">网易云音乐</a>681 次下载</td><td><a href="https://www.macappstore.net/boom-3d" title="Boom 3D 破解版 最佳Mac音效增强软件" class="title"><img src="/img/blank.gif" originalsrc="/d/file/music/2017/07-08/b3e1f31aad4eb6f30601e7b2e4af68e7.png" alt="Boom 3D">Boom 3D</a>678 次下载</td><td><a href="http://www.macappstore.net/amarra" title="Amarra 破解版" class="title"><img src="/img/blank.gif" originalsrc="/d/file/music/2015/07-17/7fce78a3d06579d2a89141b5815b5502.png" alt="Amarra">Amarra</a>576 次下载</td><td><a href="http://www.macappstore.net/vox" title="VOX Mac小巧的音乐播放器" class="title"><img src="/img/blank.gif" originalsrc="/d/file/music/2015/10-18/c4ed1635ff104fdfb717a44bdea774f2.png" alt="VOX">VOX</a>509 次下载</td>    </tr>
    </table>
    </div>


<!--PC版-->
<div id="SOHUCS" sid="321"><div id="SOHU_MAIN"><div node-type="cy-collection-btn" class="cy-collection-btn"><i></i><span>收藏文章</span></div>
<div class="module-cmt-header">
    <div class="cy-hidden">
        <button id="jump-to-kz"></button>
    </div>
    <div class="clear-g section-title-w">
        <div class="title-user-w">
            <div node-type="user" class="clear-g user-wrap-w">
                <span node-type="user-name" class="wrap-name-w"></span>
            </div>
        </div>
    </div>
    <div class="section-cbox-w">
        <div class="cbox-block-w clear-g">
            <div node-type="block-head-w" class="block-head-w">
                <div node-type="avatar" class="head-img-w">
                    <a href="javascript:void(0);">
                        <img node-type="user-head" src="https://changyan.sohu.com/upload/asset/scs/images/pic/pic42_null.gif" width="42" height="42" alt="">
                        <div node-type="head-img-ie-mask" class="head-img-ie-mask"></div>
                    </a>
                    <div node-type="notice-node" style="display: none" class="cy-avatar-notice-node"></div>
                                    </div>
                <div node-type="header-login" class="header-login">登录</div>
                <!-- <div class="cy-to-shequ-head">
                   -     <span>我的社区</span>
                   - </div> -->
                <img node-type="header-skin" class="header-skin">
                <div node-type="cy-hot-words" class="cy-hot-words"></div>
            </div>
            <div node-type="login-select" class="block-post-w">
                <!-- 放置cbox初始状态 -->
                <div class="module-cmt-box">
    <!-- 展开状态 -->
    <div class="post-wrap-w">
        <div class="post-wrap-border-l"></div>
        <div class="post-wrap-border-r"></div>
        <div node-type="post-wrap-main" class="post-wrap-main">
            <div class="post-wrap-border-t">
                <div node-type="post-wrap-border-t-l" class="post-wrap-border-t-l"></div>
                <div node-type="post-wrap-border-t-r" class="post-wrap-border-t-r"></div>
            </div>
            <div class="wrap-area-w">
                <div class="area-textarea-w">
                    <textarea node-type="textarea" name="" class="textarea-fw textarea-bf">有事没事说两句...</textarea>
                </div>
            </div>
        </div>
        <div class="clear-g wrap-action-w">
           <div class="action-function-w">
                <ul class="clear-g">
                    <li node-type="function-face" class="function-face-w">
                        <a class="effect-w" href="javascript:void(0)">
                            <i class="face-b"></i>
                        </a>
                    </li>
                    <li node-type="function-uploading" class="function-uploading-w" style="display: none;">
                        <a class="effect-w" href="javascript:void(0)" title="上传图片">
                            <i class="uploading-b"></i>
                        </a>
                        <div class="uploading-file-w">
                            <a href="javascript:void(0);" name="" class="file-fw"></a>
                        </div>
                    <form style="display: none;"><input name="file" type="file" accept="image/jpg,image/jpeg,image/png"></form></li>
                </ul>
                <!-- 表情 -->
                <div node-type="face-box" class="face-wrapper-dw">
                    <div node-type="face-cont" class="wrapper-cont-dw">
                        <ul class="clear-g">
                            <li>
                                <span title="流汗" data_path="base" data-ubb="/流汗" class="face-item face_01"></span>
                            </li>
                            <li>
                                <span title="钱" data_path="base" data-ubb="/钱" class="face-item face_02"></span>
                            </li>
                            <li>
                                <span title="发怒" data_path="base" data-ubb="/发怒" class="face-item face_03"></span>
                            </li>
                            <li>
                                <span title="浮云" data_path="base" data-ubb="/浮云" class="face-item face_04"></span>
                            </li>
                            <li>
                                <span title="给力" data_path="base" data-ubb="/给力" class="face-item face_05"></span>
                            </li>
                            <li>
                                <span title="大哭" data_path="base" data-ubb="/大哭" class="face-item face_06"></span>
                            </li>
                            <li>
                                <span title="憨笑" data_path="base" data-ubb="/憨笑" class="face-item face_07"></span>
                            </li>
                            <li>
                                <span title="色" data_path="base" data-ubb="/色" class="face-item face_08"></span>
                            </li>
                        </ul>
                        <ul class="clear-g">
                            <li>
                                <span title="奋斗" data_path="base" data-ubb="/奋斗" class="face-item face_09"></span>
                            </li>
                            <li>
                                <span title="鼓掌" data_path="base" data-ubb="/鼓掌" class="face-item face_10"></span>
                            </li>
                            <li>
                                <span title="鄙视" data_path="base" data-ubb="/鄙视" class="face-item face_11"></span>
                            </li>
                            <li>
                                <span title="可爱" data_path="base" data-ubb="/可爱" class="face-item face_12"></span>
                            </li>
                            <li>
                                <span title="闭嘴" data_path="base" data-ubb="/闭嘴" class="face-item face_13"></span>
                            </li>
                            <li>
                                <span title="疑问" data_path="base" data-ubb="/疑问" class="face-item face_14"></span>
                            </li>
                            <li>
                                <span title="抓狂" data_path="base" data-ubb="/抓狂" class="face-item face_15"></span>
                            </li>
                            <li>
                                <span title="惊讶" data_path="base" data-ubb="/惊讶" class="face-item face_16"></span>
                            </li>
                        </ul>
                        <ul class="clear-g">
                            <li>
                                <span title="可怜" data_path="base" data-ubb="/可怜" class="face-item face_17"></span>
                            </li>
                            <li>
                                <span title="弱" data_path="base" data-ubb="/弱" class="face-item face_18"></span>
                            </li>
                            <li>
                                <span title="强" data_path="base" data-ubb="/强" class="face-item face_19"></span>
                            </li>
                            <li>
                                <span title="握手" data_path="base" data-ubb="/握手" class="face-item face_20"></span>
                            </li>
                            <li>
                                <span title="拳头" data_path="base" data-ubb="/拳头" class="face-item face_21"></span>
                            </li>
                            <li>
                                <span title="酒" data_path="base" data-ubb="/酒" class="face-item face_22"></span>
                            </li>
                            <li>
                                <span title="玫瑰" data_path="base" data-ubb="/玫瑰" class="face-item face_23"></span>
                            </li>
                            <li>
                                <span title="打酱油" data_path="base" data-ubb="/打酱油" class="face-item face_24"></span>
                            </li>
                        </ul>
                    </div>
                    <div node-type="user-face-cont" class="wrapper-user-face-dw nano">
                        <div class="nano-content">
                            <ul class="clear-g">
                                <li class="upload-face-btn"></li>
                                <li class="manage-face-btn"></li>
                                <li class="cancel-face-btn"></li>
                            </ul>
                        </div>
                    </div>
                    <div node-type="face-tab" class="action-face-tab-dw">
                        <ul class="clear-g">
                            <li node-type="official-face" class="official-face-btn active"></li>
                            <li node-type="user-face" class="user-face-btn" style="display: none;"></li>
                        </ul>
                    </div>
                    <div node-type="confirm-box" class="cy-confirm-box">
                        <div class="cy-confirm-text">
                            <span>表情删除后不可恢复，是否删除</span>
                        </div>
                        <div class="cy-confirm-btn-row">
                            <div class="cy-confirm-btn-cancel">取消</div>
                            <div class="cy-confirm-btn-confirm">确定</div>
                        </div>
                    </div>
                </div>
                <!--  上传图片 --><!--  uploading-efw -->
                <div node-type="uploading-wrapper" class="uploading-wrapper-dw uploading-efw ">
                    <div class="uploading-wrapper-dw-t"></div>
                    <div class="uploading-wrapper-dw-b"></div>
                    <div node-type="image-uploading" class="wrapper-loading-dw">
                        <div class="loading-word-dw"><span class="word-icon-dw"></span>图片正在上传，请稍后...</div>
                        <div class="loading-btn-dw">
                            <a href="javascript:void(0)">取消上传</a>
                        </div>
                    </div>
                    <div node-type="image-uploaded" class="wrapper-image-dw">
                        <div class="image-close-dw">
                            <a href="javascript:void(0)"></a>
                        </div>
                        <div class="image-pic-dw">
                            <img node-type="image-pic" alt="" src="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="clear-g action-issue-w">
                <div class="issue-btn-w">
                    <a href="javascript:void(0)">
                        <button node-type="issue" class="btn-fw"></button>
                    </a>
                </div>
            <!--
            <div class="issue-icon-w" node-type="share-icons">
                </div>
            -->
            </div>
            <div class="cbox-prompt-w" node-type="error-tips">
                <span node-type="prompt-empty" class="prompt-empty-w">评论内容为空！</span>
            </div>
        </div>
    </div>
</div>
                <!-- 放置cbox发布状态 -->
                <!-- 提示条 -->
                <!-- 零评论提示条 -->
                <div class="list-comment-empty-w">
                    
                </div>
                <!-- 提示连接到快站社区 -->
                <!-- <div class="list-comment-kuaizhan-w">
                    <div node-type="kuaizhan-prompt" class="kuaizhan-prompt-w">
                        <span class="prompt-text-w">点击查看更多精彩内容</span>
                    </div>
                </div> -->
                <!--关闭评论-->
                <div class="list-close-comment-w">
                    
                </div>
            </div>
        </div>
    </div>
</div><!-- 评论列表  S -->
<div node-type="module-cmt-list" class="module-cmt-list section-list-w">
    
    <div class="cmt-list-type">
        <ul class="clear-g type-lists">
                <li class="type-list active">评论</li>
                <!-- <li class="type-list">热门</li> -->
        </ul>
        <div class="cmt-list-border"></div>
        <div class="cmt-list-number">
            <span class="comment-number"><span class="cy-number">3</span>人参与,<span class="cy-number">1</span>条评论</span>
        </div>
    </div>
            <!-- 最新评论 -->
    <div class="list-block-gw list-newest-w">
        <div node-type="cmt-list-title" class="block-title-gw">
            <ul class="clear-g">
                <li>
                    <div class="title-name-gw title-name-bg">
                    <div class="title-name-gw-tag"></div>最新评论</div>
                </li>
            </ul>
        </div>
        <div node-type="cmt-list" id="cy-cmt-list"><div node-type="cmt-item" data-id="1329598367" data-user-id="-1135210277" data-platform-id="0" class="clear-g block-cont-gw">
    <div class="cont-head-gw">
        <div class="head-img-gw">
                        <a node-type="photo" href="javascript:;" title="marlboro">
                <div class="img-corner"></div>
                <img src="//0d077ef9e74d8.cdn.sohucs.com/c_zoom,w_200/fac494264beff70ed91fedf32783552b_default_1449555825843_jpg" width="42" height="42" alt="">
            </a>
        </div>
    </div>
    <div class="cont-msg-gw">
        <div class="msg-wrap-gw">
            <div class="wrap-user-gw global-clear-spacing">
                                <span class="user-time-gw">2016年7月15日 16:28</span>
                <span node-type="nickname" class="user-name-gw"><a href="javascript:void(0)">marlboro</a></span>
                                            </div>
            
            
            <div class="wrap-issue-gw">
                <p class="issue-wrap-gw"><span class="wrap-word-gw">谢谢这个很有用</span></p>
                <div class="cy-see-more">
                    <span></span><i></i>
                </div>
            </div>
            <!-- 图片展示 -->
            
            <div node-type="btns-bar" class="clear-g wrap-action-gw">
                <div node-type="action-click-gw" class="action-click-gw global-clear-spacing">
                    <i class="gap-gw"></i>
                    <span node-type="report" class="click-report-gw"><a href="javascript:void(0)"><i class="icon-gw icon-flag"></i><em>举报</em></a></span><i class="gap-gw"></i><span node-type="reply" class="click-reply-gw"><a href="javascript:void(0)">回复</a></span>
                    <i class="gap-gw"></i>
                    <span node-type="support" class="click-ding-gw">
                        <a href="javascript:;"><i class="icon-gw icon-ding-bg"></i><em class="icon-name-bg"></em></a>
                    </span>
                    
                <i class="gap-gw"></i><span node-type="prop" class="click-prop-gw"><span class="prop-span"><a href="javascript:void(0)"></a></span></span></div>
                
            </div>
                    </div>
    </div>
</div></div>
    </div>
</div>
<!-- 评论列表  E --><div class="module-cmt-footer">
    <!-- 评论关闭 -->
    <div class="list-comment-close-w">
        <div class="close-wrap-w close-wrap-b">该评论已关闭!</div>
    </div>
    <!-- 翻页 -->
    <div class="section-page-w">
    </div>
    <!-- 某站正在使用畅言 -->
    <div class="section-service-w">
        <div class="service-wrap-w">
            <a href="http://changyan.kuaizhan.com/" target="_blank">
            
            Mac正在使用畅言
                        </a>
        </div>
    </div>
    <div node-type="cy-to-shequ" class="cy-redirect-btn">
        <span class="cy-redirect-text">去社区看看吧</span><i class="cy-right-arrow"></i>
    </div>
    <div node-type="cy-to-hots" class="cy-redirect-btn">
        <span class="cy-redirect-text">去热评看看吧</span><i class="cy-right-arrow"></i>
    </div>
    <div class="cy-to-shequ-float"></div>
</div><div class="module-cmt-notice" style="bottom: 921px;">
    <ul class="nt-list">
        
        <li node-type="notice-message" data-alias="message" data-type="message" data-static="static" class="nt-item" style=" display: none ">
            <div class="nt-logo"></div>
            <a node-type="notice-content" class="nt-text" href="javascript:void(0);">你收到<i>0</i>条新通知</a>
            <a class="nt-close" href="javascript:void(0);"></a>
        </li>
        
        <li node-type="notice-support" data-alias="support" data-type="support" data-static="static" class="nt-item" style=" display: none ">
            <div class="nt-logo"></div>
            <a node-type="notice-content" class="nt-text" href="javascript:void(0);">你有<i>0</i>条评论收到赞同</a>
            <a class="nt-close" href="javascript:void(0);"></a>
        </li>
        
        <li node-type="notice-reply" data-alias="reply" data-type="reply" data-static="static" class="nt-item" style=" display: none ">
            <div class="nt-logo"></div>
            <a node-type="notice-content" class="nt-text" href="javascript:void(0);">你有<i>0</i>条新回复</a>
            <a class="nt-close" href="javascript:void(0);"></a>
        </li>
        
        <li node-type="notice-hots" data-alias="hots" data-type="hots" data-static="static" class="nt-item" style=" display: none ">
            <div class="nt-logo"></div>
            <a node-type="notice-content" class="nt-text" href="javascript:void(0);">本日畅言热评新鲜出炉啦！</a>
            <a class="nt-close" href="javascript:void(0);"></a>
        </li>
        
        <li node-type="notice-task" data-alias="task" data-type="task" data-static="static" class="nt-item" style=" display: none ">
            <div class="nt-logo"></div>
            <a node-type="notice-content" class="nt-text" href="javascript:void(0);">你有<i>0</i>个任务已完成</a>
            <a class="nt-close" href="javascript:void(0);"></a>
        </li>
        
        <li node-type="notice-history" data-alias="history" data-type="history" data-static="static" class="nt-item" style=" display: none ">
            <div class="nt-logo"></div>
            <a node-type="notice-content" class="nt-text" href="javascript:void(0);">你收获<i>0</i>个畅言足迹</a>
            <a class="nt-close" href="javascript:void(0);"></a>
        </li>
            </ul>
</div></div></div>
<script charset="utf-8" type="text/javascript" src="style/js/changyan.js" ></script>
<script type="text/javascript">
window.changyan.api.config({
appid: 'cysUr6m2h',
conf: 'prod_67283d4ee701130f42ec637248de59e2'
});
</script>



    </div>
    </div>
<div class="wrap bottom">
	<h3>©2015 MacAppStore<span>.net</span></h3> Made by <a href="http://blank.yon.com.cn">Blank</a><br>♥ For all mac users. Amadeus Pro 破解版_Amadeus Pro for Mac_Amadeus Pro 1008<br><a href="/about">关于我们</a> <a href="/legal">版权声明</a>
</div>

<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'style/js/push.js';        
    }
    else {
        bp.src = 'style/js/push1.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<script>(function(i,s,o,g,r,a,m){i["DaoVoiceObject"]=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,"script","//widget.daovoice.io/widget/c1bea42b.js","daovoice");</script>
<script>
  daovoice('init', {
    app_id: "c1bea42b",
  });
  daovoice('update');
</script>

 <script type="text/javascript">
function Show_Hidden(trid){
    if(trid.style.display=="block"){
        trid.style.display='none';
    }else{
        trid.style.display='block';
    }
}
</script>
<script type="text/javascript" src="style/js/ajax.js"></script>
<script src="style/js/lightbox-2.6.min.js"></script>
<script>
        var h = document.getElementById("txt").clientHeight;
        if ( h > 245 ) {
            document.getElementById("txt").style.height = "245px";
            document.getElementById("txt").style.overflow = "hidden";
            document.getElementById("moretxt").style.display = "block";
            document.getElementById("more").onclick = function() {
            document.getElementById("txt").style.height = "auto";document.getElementById("moretxt").style.display = "none";
            }
        }

        function getcookie(objname)
        }

        var uname = getcookie("umulsmlusername");
        var url = document.getElementById("download_link").href;
        if (uname!="" || uname) {
            document.getElementById("download_link").href = url+"?u="+uname+"&app=Amadeus Pro";
        }

</script>
</body>
</html>