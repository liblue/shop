<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:78:"D:\0000000\phpStudy\WWW\shop\public/../application/admin\view\index\topic.html";i:1524543007;s:70:"D:\0000000\phpStudy\WWW\shop\application\admin\view\public\header.html";i:1523261997;}*/ ?>
<!DOCTYPE html>
<html>
  
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.0</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/shop/public/static/admin/css/font.css">
    <link rel="stylesheet" href="/shop/public/static/admin/css/xadmin.css">
    <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="/shop/public/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/shop/public/static/admin/js/xadmin.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
      <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
      <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  
  <body> 
    <div class="x-nav">
     
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="x-body">
      <div class="layui-row">
           <form class="layui-form layui-col-md12 x-so" action="<?php echo url('admin/index/topic'); ?>"  method="post">
        
          <input type="text" name="topic_title"  placeholder="请输入标题" autocomplete="off" class="layui-input">
          <button class="layui-btn"   ><i class="layui-icon">&#xe615;</i></button>
          
          
      
        </form>
      </div>
      <xblock>
        <button class="layui-btn layui-btn-danger" onclick="delAll()"><i class="layui-icon"></i>批量删除</button>
  
        <a  href="<?php echo url('admin/index/topic'); ?>"> <button class="layui-btn" >查看全部</button></a>
        <span class="x-right" style="line-height:40px">共有数据：88 条</span>
      </xblock>
      <table class="layui-table">
        <thead>
          <tr>
            <th>
              <div class="layui-unselect header layui-form-checkbox" ><i class="layui-icon">&#xe605;</i></div>
            </th>
            <th>ID</th>
            <th>标题</th>
            <th>回复</th>
            <th>用户</th>
            <th>日期</th>
         
            <th>操作</th></tr>
        </thead>
        <tbody>
            
            <?php foreach($data as $k=>$v): ?>
          <tr>
            <td>
              <div class="layui-unselect layui-form-checkbox"  data-id='<?php echo $v['topic_id']; ?>'><i class="layui-icon">&#xe605;</i></div>
            </td>
            <td><?php echo $k+1; ?></td>
          <td><?php echo $v['topic_title']; ?></td>
            <td><?php echo $v['topic_number']; ?></td>
            <td><?php echo $v['user_name']; ?></td>
            <td><?php echo $v['created_at']; ?></td>
           
        
            <td class="td-manage">
             
              <a title="删除" onclick="member_del(this,'<?php echo $v['topic_id']; ?>')" href="javascript:;">
                <i class="layui-icon">&#xe640;</i>
              </a>
            </td>
          </tr>
          
     <?php endforeach; ?>

        </tbody>
      </table>
      <div class="page">
        <div>
         <?php $__FOR_START_13445__=1;$__FOR_END_13445__=$fenye+1;for($i=$__FOR_START_13445__;$i < $__FOR_END_13445__;$i+=1){ if($i == $page): ?>
           <span class="current"><?php echo $i; ?></span>
           <?php else: ?>
           <a class="num" href="<?php echo url('admin/index/topic'); ?>?page=<?php echo $i; ?>"><?php echo $i; ?></a>
           <?php endif; } ?>
        </div>
      </div>

    </div>
    <script>

 


      layui.use('laydate', function(){
        var laydate = layui.laydate;
        
        //执行一个laydate实例
        laydate.render({
          elem: '#start' //指定元素
        });

        //执行一个laydate实例
        laydate.render({
          elem: '#end' //指定元素
        });
      });

       /*用户-停用*/
      function member_stop(obj,id){
          layer.confirm('确认要停用吗？',function(index){

              if($(obj).attr('title')=='启用'){

                //发异步把用户状态进行更改
                $(obj).attr('title','停用')
                $(obj).find('i').html('&#xe62f;');

                $(obj).parents("tr").find(".td-status").find('span').addClass('layui-btn-disabled').html('已停用');
                layer.msg('已停用!',{icon: 5,time:1000});

              }else{
                $(obj).attr('title','启用')
                $(obj).find('i').html('&#xe601;');

                $(obj).parents("tr").find(".td-status").find('span').removeClass('layui-btn-disabled').html('已启用');
                layer.msg('已启用!',{icon: 5,time:1000});
              }
              
          });
      }

      /*用户-删除*/
      function member_del(obj,id){
          layer.confirm('确认要删除吗？',function(index){
              //发异步删除数据
              
              $(obj).parents("tr").remove();
              layer.msg('已删除!',{icon:1,time:1000});
              $.ajax({    
                    type:"post",    
                    url:"<?php echo url('admin/tool/update'); ?>",    
                    data:{id:id},//这里data传递过去的是序列化以后的字符串    
                    success:function(data){    
               //获取成功以后输出返回值    
     
                    }    
                }); 
              
              
          });
      }



      function delAll (argument) {

        var data = tableCheck.getData();
 
        layer.confirm('确认要删除吗？',function(index){
            //捉到所有被选中的，发异步进行删除
          
            layer.msg('删除成功', {icon: 1});
            $(".layui-form-checked").not('.header').parents('tr').remove();
            
                 $.ajax({    
                    type:"post",    
                    url:"<?php echo url('admin/tool/update'); ?>",    
                    data:{id:data},//这里data传递过去的是序列化以后的字符串    
                    success:function(data){    
               //获取成功以后输出返回值    
     
                    }    
                }); 
            
        });
      }
    </script>
    <script>var _hmt = _hmt || []; (function() {
        var hm = document.createElement("script");
        hm.src = "https://hm.baidu.com/hm.js?b393d153aeb26b46e9431fabaf0f6190";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
      })();</script>
  </body>

</html>