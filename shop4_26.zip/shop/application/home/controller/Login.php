<?php

namespace app\home\controller;

use think\Controller;
use think\Request;
use app\home\model\User;
use think\Db;

class Login extends Common
{
    //登录
    public function login(Request $request)
    {
        if ($data = $request->post()) {
            //判断验证码
            if (!captcha_check($data['user_code'])) {
                $this->error('验证码不正确');
            }
            $name = $data['user_name'];
            $pass = $data['user_pass'];

            $result = Db::table('user')->where('user_name', $name)->select();
            $user_id = $result[0]['user_id'];
            if ($result != null) {
                $password = $result[0]['user_pass'];
                $password = base64_decode($password);//解密

                if ($password == $pass) {
                    session('user_name', $name);
                    session('user_id', $user_id);
                    return $this->success('用户登录成功', './'.'home/index');
                } else {
                    return $this->error('用户密码错误');
                }
            } else {
                return $this->error('用户不存在');
            }
            $this->assign('result', $result);
            $this->redirect('index');
        } else {
            return view('login');
        }
    }

    //注册
    public function register(Request $request)
    {
        if ($data = $request->post()) {
            $file = request()->file('user_thum');
            (empty($file)) ? $this->error('请选择上传文件') : '';
            $info = $file->move(ROOT_PATH . 'touxiang/');
            $user_thum = $info->getSaveName();
            $data['user_thum'] = $user_thum;

            $user_pass = $data['user_pass'];
            $pass = $data['pass'];
            $user_name = $data['user_name'];
            if ($user_pass == $pass) {
                unset($data['pass']);
                $user_pass = base64_encode($user_pass);//加密
                $re = Db::table('user')->where('user_name', $user_name)->select();
                if ($re == null) {
                    $data['user_pass'] = $user_pass;
                    $user=Db::name('user')->insert($data);
                    return $this->success('用户注册成功', './'.'home/index');
                } else if (strlen($user_name) < 6) {
                    return $this->error('用户名已被注册或者用户名长度要大于6');
                }
            } else {
                return $this->error('两次密码不一致');
            }
        } else {
            return view('register');
        }
    }

    //登出
    public function logout()
    {
        session('user_name', null);
        session('user_id', null);
        $this->redirect('index');
    }

}
