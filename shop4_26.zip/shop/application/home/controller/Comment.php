<?php

namespace app\home\controller;

use app\home\model\Reply;
use think\Controller;
use think\Request;
use app\home\model\Nav;
use app\home\model\User;
use think\Collection;


class Comment extends Common
{
    public function index()
    {
        $page = model('topic')->order('created_at','desc')->where('topic_pid',0)->paginate(2);
        $this->assign('page', $page);
        $newtopic=$page;
        foreach($page as $k=>$v){
            $user=User::find($v['user_id']);
            $newtopic[$k]['user']=$user;
        }
        $this->assign('newtopic', $newtopic);
        return view('comment');
    }

    //用户回答
    public function reply($topic_id)
    {
        $topic = model('topic')->where('topic_id',$topic_id)->find();
        $this->assign('topic', $topic);
        $id=$topic['user_id'];
        $userd=model('user')->where('user_id',$id)->find();
        $this->assign('userd',$userd);
        $topic=model('topic')->where('topic_pid',$topic_id)->select();
        $newtopic=$topic;
        foreach ($topic as $k=>$v){
            $user=User::find($v['user_id']);
            $newtopic[$k]['user']=$user;
        }
        $this->assign('newtopic', $newtopic);
        return view('reply');
    }

//回答问提插入数据
    public function answer(Request $request){
        $user_id=$request->session('user_id');
        $data = $request->post();
        $data['user_id']=$user_id;
        $data['topic_pid']=$data['topic_id'];
        $id=$data['topic_id'];
        unset($data['topic_id']);
        $topic=model('topic')->insert($data);
        $topic=model('topic')->get($id);
        $topic_number=$topic->topic_number+1;
        $topic->topic_number=$topic_number;
         $topic->save();
        return $this->success('评论成功');
    }

    public function release(Request $request){
        if($data = $request->post()){
            $user_id=$request->session('user_id');
            $data['user_id']=$user_id;
            $topic=model('topic')->insert($data);
            return $this->success('发帖成功');
        }
        return view('release');
    }
}
