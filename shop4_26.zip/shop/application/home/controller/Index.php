<?php

namespace app\home\controller;

use think\Controller;
use think\Request;
use app\home\model\Nav;
use app\home\model\Tool;
use app\home\model\Kit;
use app\home\model\User;
use think\Db;
use app\home\model\Answer;

class Index extends Common
{
    public function index(Request $request)
    {
        $tool =model('tool')->order('tool_time','desc')->select();
        $this->assign('tool', $tool);
        $user_id=$request->session('user_id');
        $user=model('user')->where('user_id',$user_id)->select();
        $this->assign('user', $user);
        $user_name=$request->session('user_name');

        $news=model('news')->where('news_reply',$user_name)->order('date','asc')->select();
        $this->assign('news', $news);
        return view('');
    }
    public function software()
    {
        $menu_model = new kit();
        $kit =$menu_model::all();
        $kitr=Db::table('kit')->where('kit_pid',1)->select();
        $this->assign('kitr', $kitr);
        return view('software');
    }

    public function game()
    {
        $menu_model = new kit();
        $kit =$menu_model::all();
        $kitg=Db::table('kit')->where('kit_pid',2)->select();
        $this->assign('kitg', $kitg);
        return view();
    }

    public function entry($tool_type)
    {
        $tool=Db::table('tool')->where('tool_type',$tool_type)->select();
        $this->assign('tool', $tool);
        return view('entry');
    }
    public function content(Request $request,$tool_id)
    {
        $tool=Db::table('tool')->where('tool_id',$tool_id)->find();
        $this->assign('tool', $tool);
        $tool_type=$tool['tool_type'];
        $pai=Db::table('tool')->where('tool_type',$tool_type)->order('tool_download','desc')->limit(4)->select();
        $this->assign('pai', $pai);

        //工具评论
        $problem=model('problem')->where('tool_id',$tool_id)->where('pro_pid',0)->select();
        $newproblem=$problem;
        foreach($problem as $k=>$v) {
            $pro_id = $v['pro_id'];
            $user = User::find($v['user_id']);
            $newproblem[$k]['user']=$user;
            $newproblem[$k]['answer'] = model('problem')->where('pro_pid', $pro_id)->select();
            $answer=$newproblem[$k]['answer'];
            foreach($newproblem[$k]['answer'] as $key=>$value){
                $user = User::find($value['user_id']);
                $answer[$key]['user']=$user['user'];
            }
            $newproblem[$k]['answer']=$answer;
        }
        $this->assign('newproblem', $newproblem);
        return view('content');
    }

    //工具提问
    public function contentadd(Request $request){
        $data = $request->post();
        $user_id=$request->session('user_id');
        $data['user_id']=$user_id;
        Db::table('problem')->insert($data);
        return $this->success('评论成功');

    }

    //工具提问回答
    public function problem(Request $request){
        $data = $request->post();
        $user_id=$request->session('user_id');
        $data['user_id']=$user_id;
        $data['pro_pid']=$data['pro_id'];
        unset($data['pro_id']);
        Db::table('problem')->insert($data);
        return $this->success('回复评论成功');
    }

    //用户直接和客服交谈
    public function read(Request $request){
        $data = $request->post();
        $user_name=$request->session('user_name');
        $data['user_name']=$user_name;
        $data['news_reply']=$user_name;
        $news=model('news')->insert($data);

        $this->assign('news', $news);
        return view('index');
    }

    public function rankings()
    {
        $toolnumber=Db::table('tool')->order('tool_download','desc')->select();
        $this->assign('toolnumber',$toolnumber);
        $name="本月";
        $this->assign('name',$name);
        return view('rankings');
    }

    public function xiazai(){
        $toolnumber=Db::table('tool')->order('tool_time','desc')->select();
        $this->assign('toolnumber',$toolnumber);
        $name="下载量";
        $this->assign('name',$name);
        return view('rankings');
    }

}
