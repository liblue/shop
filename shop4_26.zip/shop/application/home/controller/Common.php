<?php

namespace app\home\controller;

use think\Controller;
use think\Request;
use app\home\model\Nav;
use app\home\model\User;

class Common extends Controller
{
    function _initialize()
    {
        //导航
        $menu_model = new nav();
        $nav =$menu_model::all();
        $this->assign('nav', $nav);

        //最热标题
        $hot=model('topic')->order('topic_number','desc')->where('topic_pid',0)->paginate(5);
        $this->assign('hot', $hot);
        $newhot=$hot;
        foreach($hot as $k=>$v){
            $user=User::find($v['user_id']);
            $newhot[$k]['user']=$user;
        }
        $this->assign('newhot', $newhot);
    }
}
