<?php

namespace app\home\model;

use think\Model;

class Tool extends Model
{
    public function tool(){
        return $this->hasOne('tool','','tool_id');
    }
}
