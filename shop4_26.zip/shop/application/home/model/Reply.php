<?php

namespace app\home\model;

use think\Model;

class Reply extends Model
{
    public function Reply(){
        return $this->hasOne('reply','topic_id','reply_id');
    }
}
