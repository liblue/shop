<?php

namespace app\home\model;

use think\Model;

class Answer extends Model
{
    public function nav(){
        return $this->hasOne('answer','','an_id');
    }
}
