<?php

namespace app\home\model;

use think\Model;

class Kit extends Model
{
    public function nav(){
        return $this->hasOne('kit','kit_pid','kid_id');
    }
}
