<?php

namespace app\home\model;

use think\Model;

class Nav extends Model
{
    public function nav(){
        return $this->hasOne('nav','','nav_id');
    }

}
