<?php

namespace app\home\model;

use think\Model;

class News extends Model
{
    public function News(){
        return $this->hasOne('news','','news_id');
    }
}
