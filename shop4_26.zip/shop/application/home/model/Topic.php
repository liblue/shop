<?php

namespace app\home\model;

use think\Model;

class Topic extends Model
{
    public function Topic(){
        return $this->hasOne('topic','','topic_id');
    }
}
