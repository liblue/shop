<?php

namespace app\home\model;

use think\Model;

class Problem extends Model
{
    public function Answer(){
        return $this->hasOne('problem','','pro_id');
    }
}
