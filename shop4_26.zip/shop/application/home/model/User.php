<?php

namespace app\home\model;

use think\Model;

class User extends Model
{
    public function User(){
        return $this->hasOne('user','','user_id');
    }
}
