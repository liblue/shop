<?php

namespace app\admin\controller;

use think\Controller;
use think\Request;
use app\admin\model\User as Users;
class User extends Base
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index(Request $request)
    {
       $num=2;
       $data1 =Users::select();
       $data =Users::paginate($num);
           
       if($request->post('username')){
           
         $user_name=$request->post('username');
         $data1=Users::where('user_name','like',"%{$user_name}%")->select();
         $data=Users::where('user_name','like',"%{$user_name}%")->paginate($num);
       }
       if($request->get('page')){
            $page=$request->get('page');
         }else{
            $page=1;
         }
     
       $count=count($data1);
        $fenye=ceil($count/$num);
    
        $this->assign('count',$count);
         $this->assign('fenye',$fenye);
         $this->assign('page',$page);
         $this->assign('data',$data);
         return $this->fetch();
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        
       $input=input();
        $id=$input['id'];
        
       Users::destroy($id);
            return $id;
    }

     public function add(){

        return view();
    }
}
