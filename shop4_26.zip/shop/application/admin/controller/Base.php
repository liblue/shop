<?php

namespace app\Admin\controller;

use think\Controller;
use think\Request;
use think\Session;
class Base extends Controller
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function _initialize(){
        
       
        $uid = session('user_name');
          $uid = session('uid');
        if($uid == null){
            $this->redirect('admin/login/login','请先登录后操作');
        }
    }
    
    public function dd($a){
        
        dump($a);
        die();
    }

}
