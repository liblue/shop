<?php

namespace app\admin\controller;

use think\Controller;
use think\Request;
use app\admin\model\Tool as Tools;
use app\home\model\Problem;
use app\home\model\Kit;
use app\admin\model\User;
class Tool extends Base
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index(Request $request)
    {
        //
         $num=5;
         $kit=Kit::all();
         $data1 =Tools::select();
         $data =Tools::paginate($num);
      
          if($request->post('kit')&&$request->post('toolname')){
            
            $kit_type=$request->post('kit');
            $toolname=$request->post('toolname');
            $data1=Tools::where('tool_type',$kit_type)->where('tool_name','like',"%{$toolname}%")->select();
            $data=Tools::where('tool_type',$kit_type)->where('tool_name','like',"%{$toolname}%")->paginate($num);
            }
            elseif($request->post('kit')){
               
                 $kit_type=$request->post('kit');
                 $data1=Tools::where('tool_type',$kit_type)->select();
                 $data=Tools::where('tool_type',$kit_type)->paginate($num);
            }elseif($request->post('toolname')){
               
                 $toolname=$request->post('toolname');
                 $data1=Tools::where('tool_name','like',"%{$toolname}%")->select();
                 $data=Tools::where('tool_name','like',"%{$toolname}%")->paginate($num);
            }else{
              
                
            }
         
        
         if($request->get('page')){
            $page=$request->get('page');
         }else{
            $page=1;
         }
        
        $count=count($data1);
        $fenye=ceil($count/$num);
        $this->assign('count',$count);
         
         $this->assign('fenye',$fenye);
         $this->assign('page',$page);
         $this->assign('kit',$kit);
         $this->assign('data',$data);
         return $this->fetch();
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
        
      $input=input();
      
      unset($input['point']);
      unset($input['method']);
       unset($input['imgs']);
      Tools::insert($input);
       return $this->success('添加成功', 'admin/tool/add');
      
    }

    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit()
    {
        $id=input()['id'];
        $data=Tools::find($id);
        $this->assign('data',$data);
        return $this->fetch();
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request)
    {
     
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete()
    {
       $input=input();
        $id=$input['id'];
        
       Tools::destroy($id);
            return $id;
    }

    public function add(){
        $kit =Kit::all();
        $this->assign('kit',$kit);
        return $this->fetch();
    }
      public function problem( Request $request)
    {
        $num=3;
        $data1=Problem::all();
        $data=Problem::paginate($num);
         foreach ($data as $k=>$v){
             
             
         }
 
        if($request->get('page')){
            $page=$request->get('page');
         }else{
            $page=1;
         }
        $count=count($data1);
        $fenye=ceil($count/$num);
        $this->assign('count',$count);
        $this->assign('page',$page);
        $this->assign('fenye',$fenye);
        $this->assign('data',$data); 
        return $this->fetch();
    }
     public function pro_del()
    {
          
          $input=input();
          $id=$input['id'];
         
          Problem::destroy($id);
            return $id;
    }
    public function kit(){
         $data=Kit::order('kit_id desc')->select();
         $count=count($data);
         $this->assign('data',$data); 
         $this->assign('count',$count); 
        return $this->fetch();
    }
    public function kit_del()
    {
          
          $input=input();
          $id=$input['id'];
         
         Kit::destroy($id);
            return $id;
    }
       public function kit_add(Request $request)
    {
          
        
         
         $input=input();
         Kit::insert($input);
            return  1;
    }
    
    
    
    
    
    
}
