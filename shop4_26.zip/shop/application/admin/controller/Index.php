<?php
namespace app\admin\controller;
use app\admin\model\Topic;
use app\admin\model\User;
use think\Request;
class Index extends Base
{
    public function index()
    {
        return view();
    }
    public function welcome()
    {
        return view();
    }
    public function topic(Request $request)
    {
       $num=2;
       $data1 =Topic::where('topic_pid',0)->select();
       $data =Topic::where('topic_pid',0)->paginate($num);
         if( $request->post('topic_title') ){
             
          
            $topic_title=$request->post('topic_title');
              
            $data1=Topic::where('topic_pid',0)->where('topic_title','like',"%{$topic_title}%")->select();
            $data=Topic::where('topic_pid',0)->where('topic_title','like',"%{$topic_title}%")->paginate($num);  
         }
   
       if($request->get('page')){
            $page=$request->get('page');
         }else{
            $page=1;
         }
         
         $re=$data;
       foreach($data as $k=>$v){
           
           $user=User::find($v['user_id']);
           $re[$k]['user_name']=$user['user_name'];
       }
       
       $data=$re;
        $count=count($data1);
        $fenye=ceil($count/$num);
    
         $this->assign('count',$count);
         $this->assign('fenye',$fenye);
         $this->assign('page',$page);
         $this->assign('data',$data);
         return $this->fetch();
    }
    
    

}
