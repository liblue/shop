<?php

namespace app\admin\controller;

use think\Controller;
use think\Request;
Use app\admin\model\User as Users;

class Admin extends Base
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index(Request $request)
    {
       $num=2;
       $data1 =Users::where('is_admin',1)->select();
       $data =Users::where('is_admin',1)->paginate($num);
           
       if($request->post('username')){
           
         $user_name=$request->post('username');
         $data1=Users::where('user_name','like',"%{$user_name}%")->where('is_admin',1)->select();
         $data=Users::where('user_name','like',"%{$user_name}%")->where('is_admin',1)->paginate($num);
       }
       if($request->get('page')){
            $page=$request->get('page');
         }else{
            $page=1;
         }
     
       $count=count($data1);
        $fenye=ceil($count/$num);
    
        $this->assign('count',$count);
         $this->assign('fenye',$fenye);
         $this->assign('page',$page);
         $this->assign('data',$data);
         return $this->fetch();
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function create()
    {
        //
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {
        //
        
        $input=input();
        unset($input['repass']);
        $input['is_admin']=1;
        $input['user_pass'] = base64_decode(  $input['user_pass']);
        Users::create($input);
       
          return $this->success('添加成功', 'admin/admin/add');
    }

    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit(Request $request)
            
    {
       
            $user_id=$request->get('id');
            $data=Users::find($user_id);
            $this->assign('data',$data);
            return $this->fetch();
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request)
    {
        //
        $input=input();
        $id=$input['user_id'];
        $user=Users::get($id);
        
 
       if($user['user_pass']==$input['user_pass']){
           unset($input['user_pass']);
       }else{
         $input['user_pass']= base64_decode($input['user_pass']);
     
       }
         Users::where('user_id', $id)->update($input);
//        file_put_contents('2.txt',  $password);
          return  1;
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }

    public function add(){

        return view();
    }
}
