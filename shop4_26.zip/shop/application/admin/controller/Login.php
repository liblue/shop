<?php
namespace app\admin\controller;

use think\Session;
class Login 
{
    
   
    public function login()
    {
        if($input= input()){
            
            
            
        Session::set('user_name','black');
          Session::set('uid','black');
        return redirect('admin/index/index');
        }
        return view();
    }
     public function logout()
    {
        
         Session::clear();
        return redirect('admin/login/login');
    }
}
