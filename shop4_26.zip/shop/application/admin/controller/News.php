<?php

namespace app\admin\controller;

use think\Controller;
use think\Request;
use app\home\model\News as Newss;
use think\Db;

class News extends Base
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index()
    {
        //
      
        $data=  Db::table('news')->where('user_name','<>','black')->group('user_name') ->select();
        $this->assign('data',$data);
        
        return $this->fetch(); 
    }

    /**
     * 显示创建资源表单页.
     *
     * @return \think\Response
     */
    public function content(Request $request)
    {
        //
        
     
         $user_name=$request->get('user_name');
         $data=Newss::where('news_reply', $user_name)->select();
         $res=Newss::where('user_name', $user_name)->select();
         $question=count($res);
         
     
         $this->assign('user_name',$user_name);
         $this->assign('data',$data);
         $this->assign('question', $question);
        return $this->fetch();
    }

    /**
     * 保存新建的资源
     *
     * @param  \think\Request  $request
     * @return \think\Response
     */
    public function save(Request $request)
    {   
        $user_name='black';
        $data=$request->post();
        $data['user_name']=$user_name;
         Newss::insert($data);
      return 1;
        //
    }

    /**
     * 显示指定的资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function read($id)
    {
        //
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        //
    }
    public function find(Request $request)
    {
        //
        $data=$request->post();
        $user_name=$data['user_name'];
        $question=$data['question'];
        $res=Newss::where('user_name', $user_name)->select();
        $count= count($res);
        $num=$count-$question;
          if($num>0){
              $res1=Newss::where('user_name', $user_name)->order('news_id','desc')->select();
              $dian=$res1[0]['news_content'];
              return $dian;
          }
          return 'no';
    }
}
