<?php

namespace app\admin\model;

use think\Model;

class Kit extends Model
{
    //
}
