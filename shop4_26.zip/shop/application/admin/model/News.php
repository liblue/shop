<?php

namespace app\admin\model;

use think\Model;

class News extends Model
{
    //
}
