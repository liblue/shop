<?php

namespace app\admin\model;

use think\Model;

class Tool extends Model
{
    //
}
