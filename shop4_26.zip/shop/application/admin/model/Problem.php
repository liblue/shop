<?php

namespace app\admin\model;

use think\Model;

class Problem extends Model
{
    //
}
