<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

use think\Route;

//登录
Route::any('home/login','home/Login/login');
//登出
Route::any('home/logout','home/Login/logout');
//注册
Route::any('home/register','home/Login/register');
//软件
Route::get('home/software','home/Index/software');
Route::get('home/entry','home/Index/entry');
//排行榜
Route::get('home/rankings','home/Index/rankings');
//游戏
Route::get('home/game','home/Index/game');

//内容


//评论
Route::get('home/comment','home/Comment/index');
Route::get('home/reply','home/Comment/reply');
Route::post('home/answer','home/Comment/answer');
Route::any('home/release','home/Comment/release');





